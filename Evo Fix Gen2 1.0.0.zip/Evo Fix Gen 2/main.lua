return function(mod)
  local Evolution = require("src.core.gen2.Evolution")

  local function isNight(timeOfDay)
    return timeOfDay == Evolution.NITE or timeOfDay == "NITE_F"
  end

  -- =====================================================================
  -- 1. Helper: Find the level a Pokémon exhausts its learnset
  -- =====================================================================
  local function getExhaustedLearnsetLevel(data, species)
    local def = data and data.pokemon and data.pokemon[species]
    local maxLevel = 0
    
    for _, row in ipairs((def and def.levelMoves) or {}) do
      if row.level > maxLevel then
        maxLevel = row.level
      end
    end
    
    if maxLevel == 0 then return 40 end
    return maxLevel
  end

  -- =====================================================================
  -- 2. SAFEGUARD: Protect unrelated items during forced Trade Evolutions
  -- =====================================================================
  local origApply = Evolution.apply
  function Evolution.apply(data, mon, entry)
    local originalItem = mon.item
    local evolved = origApply(data, mon, entry)
    
    -- If it was a trade evolution that expects an item, but the Pokémon evolved
    -- via our level-up fallback holding something else (like an EXP_SHARE),
    -- restore the item that the vanilla engine incorrectly deleted!
    if evolved and entry.method == Evolution.TRADE and entry.item and originalItem ~= entry.item then
      evolved.item = originalItem
    end
    
    return evolved
  end

  -- =====================================================================
  -- 3. Evolution Override: Trades, Happiness, and Late Stones
  -- =====================================================================
  mod.hooks:wrap("evolution.check", function(nextFn, data, mon, evo, ctx)
    if nextFn(data, mon, evo, ctx) then 
      return true 
    end
    
    ctx = ctx or {}
    
    if Evolution.holdsEverstone(mon) then return false end
    if ctx.link or ctx.force then return false end
    
    local targetLevel = getExhaustedLearnsetLevel(data, mon.species)
    local isAtTargetLevel = (mon.level or 0) >= targetLevel
    
    -- A. TRADE EVOLUTIONS
    if evo.method == Evolution.TRADE then
      if evo.item then
        -- EVOLVE IF: Holding the correct item (any level) OR reached target level
        return mon.item == evo.item or isAtTargetLevel
      else
        -- No item required (Kadabra, Machoke), just need target level
        return isAtTargetLevel
      end
    
    -- B. HAPPINESS EVOLUTIONS
    elseif evo.method == Evolution.HAPPINESS then
      if isAtTargetLevel then
        local trigger = evo.time or Evolution.ANYTIME
        if trigger == Evolution.NITE and not isNight(ctx.timeOfDay) then return false end
        if trigger == Evolution.MORNDAY and isNight(ctx.timeOfDay) then return false end
        return true
      end

    -- C. STONE EVOLUTIONS (Item)
    elseif evo.method == Evolution.ITEM then
      if isAtTargetLevel and mon.species ~= "EEVEE" then
        return true
      end
    end
    
    return false
  end)

  -- =====================================================================
  -- 4. Ultimate Moves & Catch-up Evolution Moves
  -- =====================================================================
  local ULTIMATE_MOVES = {
    -- Gen 1 Stone Evolutions
    ARCANINE   = { "FLAMETHROWER", "EXTREMESPEED" },
    NINETALES  = { "FLAMETHROWER", "FIRE_SPIN" },
    RAICHU     = { "THUNDERBOLT", "THUNDER" },
    CLEFABLE   = { "METRONOME", "MOONLIGHT" },
    WIGGLYTUFF = { "METRONOME", "DOUBLE_EDGE" },
    NIDOKING   = { "SLUDGE_BOMB", "EARTHQUAKE" },
    NIDOQUEEN  = { "SLUDGE_BOMB", "EARTHQUAKE" },
    VILEPLUME  = { "PETAL_DANCE", "SOLARBEAM" },
    VICTREEBEL = { "RAZOR_LEAF", "SLUDGE_BOMB" },
    POLIWRATH  = { "HYDRO_PUMP", "DYNAMICPUNCH" },
    CLOYSTER   = { "ICE_BEAM", "SPIKES" },
    EXEGGUTOR  = { "PSYCHIC_M", "PSYCHIC", "SOLARBEAM" }, 
    STARMIE    = { "HYDRO_PUMP", "PSYCHIC_M", "PSYCHIC" },
    
    -- Eeveelutions
    VAPOREON   = { "HYDRO_PUMP", "ICE_BEAM" },
    JOLTEON    = { "THUNDER", "BITE" },
    FLAREON    = { "FLAMETHROWER", "FIRE_SPIN" },
    ESPEON     = { "PSYCHIC_M", "PSYCHIC", "MORNING_SUN" },
    UMBREON    = { "FAINT_ATTACK", "MOONLIGHT" },
    
    -- Gen 2 Stone Evolutions
    BELLOSSOM  = { "SUNNY_DAY", "SOLARBEAM" },
    SUNFLORA   = { "SUNNY_DAY", "SOLARBEAM" },
    
    -- Gen 2 Trade / Happiness Evolutions
    STEELIX    = { "IRON_TAIL", "EARTHQUAKE" },
    SCIZOR     = { "METAL_CLAW", "SWORDS_DANCE" },
    POLITOED   = { "HYDRO_PUMP", "PERISH_SONG" },
    SLOWKING   = { "PSYCHIC_M", "PSYCHIC", "CONFUSION" },
    KINGDRA    = { "HYDRO_PUMP", "DRAGONBREATH" },
    PORYGON2   = { "TRI_ATTACK", "ZAP_CANNON" },
    CROBAT     = { "WING_ATTACK", "CONFUSE_RAY" },
    BLISSEY    = { "SOFTBOILED", "HEAL_BELL" },
    
    -- Custom Additions
    TOGETIC    = { "ANCIENTPOWER", "METRONOME" }
  }

  function Evolution.learnedOnEvolve(data, species, level, mon)
    local def = data and data.pokemon and data.pokemon[species]
    local known = {}
    
    for _, move in ipairs((mon and mon.moves) or {}) do 
      known[move.id] = true 
    end
    
    local out = {}
    
    -- Feature A: Catch-up Moves
    for _, row in ipairs((def and def.levelMoves) or {}) do
      if row.level <= level and not known[row.move] then
        known[row.move] = true
        out[#out + 1] = row.move
      end
    end

    -- Feature B: Ultimate Moves
    local ultimates = ULTIMATE_MOVES[species]
    if ultimates then
      for _, moveId in ipairs(ultimates) do
        if not known[moveId] then
          known[moveId] = true
          out[#out + 1] = moveId
        end
      end
    end
    
    return out
  end

  mod.log:info("Expanded Ultimate Evolution Mod: Loaded successfully!")
end
