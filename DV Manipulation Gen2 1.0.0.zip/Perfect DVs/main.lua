return function(mod)

  -- ==========================================
  -- 1. OPTIMAL DV PROFILES
  -- ==========================================
  -- Mathematically perfect DVs for Max stats, Shiny combinations, and 70 BP Hidden Powers
  local DV_PROFILES = {
    { label = "MAX STATS (HP DARK)", dvs = { attack = 15, defense = 15, speed = 15, special = 15 } },
    { label = "SHINY HP DRAGON 69",  dvs = { attack = 15, defense = 10, speed = 10, special = 10 } },
    { label = "SHINY HP GRASS 69",   dvs = { attack = 14, defense = 10, speed = 10, special = 10 } },
    { label = "HP FIGHTING 70",      dvs = { attack = 12, defense = 12, speed = 15, special = 15 } },
    { label = "HP FLYING 70",        dvs = { attack = 12, defense = 13, speed = 15, special = 15 } },
    { label = "HP POISON 70",        dvs = { attack = 12, defense = 14, speed = 15, special = 15 } },
    { label = "HP GROUND 70",        dvs = { attack = 12, defense = 15, speed = 15, special = 15 } },
    { label = "HP ROCK 70",          dvs = { attack = 13, defense = 12, speed = 15, special = 15 } },
    { label = "HP BUG 70",           dvs = { attack = 13, defense = 13, speed = 15, special = 15 } },
    { label = "HP GHOST 70",         dvs = { attack = 13, defense = 14, speed = 15, special = 15 } },
    { label = "HP STEEL 70",         dvs = { attack = 13, defense = 15, speed = 15, special = 15 } },
    { label = "HP FIRE 70",          dvs = { attack = 14, defense = 12, speed = 15, special = 15 } },
    { label = "HP WATER 70",         dvs = { attack = 14, defense = 13, speed = 15, special = 15 } },
    { label = "HP GRASS 70",         dvs = { attack = 14, defense = 14, speed = 15, special = 15 } },
    { label = "HP ELECTRIC 70",      dvs = { attack = 14, defense = 15, speed = 15, special = 15 } },
    { label = "HP PSYCHIC 70",       dvs = { attack = 15, defense = 12, speed = 15, special = 15 } },
    { label = "HP ICE 70",           dvs = { attack = 15, defense = 13, speed = 15, special = 15 } },
    { label = "HP DRAGON 70",        dvs = { attack = 15, defense = 14, speed = 15, special = 15 } },
  }

  -- ==========================================
  -- 2. MOD OPTIONS MENU
  -- ==========================================
  local choices = {}
  for i, profile in ipairs(DV_PROFILES) do
    table.insert(choices, { profile.label, tostring(i) })
  end

  mod.options:define({
    {
      key = "dv_target",
      label = "DV TARGET PROFILE",
      type = "choice",
      default = "1",
      choices = choices
    }
  })

  -- ==========================================
  -- 3. PARTY MENU SUBMENU INJECTION
  -- ==========================================
  mod.hooks:wrap("ui.party.submenu", function(nextFn, game, items, mon, ctx)
    -- Fetch the vanilla menu items first
    local menuItems = nextFn(game, items, mon, ctx)
    
    -- Find the best place to insert our button (usually right before "CANCEL")
    local insertPos = #menuItems
    if menuItems[#menuItems] and menuItems[#menuItems].id == "CANCEL" then
      insertPos = #menuItems
    else
      insertPos = #menuItems + 1
    end

    -- Inject our custom "APPLY DVS" button into the submenu hook
    table.insert(menuItems, insertPos, {
      id = "APPLY_DVS",
      label = "APPLY DVS",
      onSelect = function(selectedMon, currentGame)
        -- Grab the profile the player chose in the Mod Options menu
        local profileIndex = tonumber(mod.options:get("dv_target")) or 1
        local profile = DV_PROFILES[profileIndex]
        
        if not profile then return end
        
        -- Load the Gen 2 Mon module safely
        local Mon
        pcall(function() Mon = package.loaded["src.battle.gen2.Mon"] or require("src.battle.gen2.Mon") end)
        if not Mon then return end

        -- 1. Apply the primary DVs
        selectedMon.dvs.attack = profile.dvs.attack
        selectedMon.dvs.defense = profile.dvs.defense
        selectedMon.dvs.speed = profile.dvs.speed
        selectedMon.dvs.special = profile.dvs.special
        
        -- 2. Let the engine calculate the mathematical HP DV
        selectedMon.dvs.hp = Mon.hpDV(selectedMon.dvs)

        -- 3. Recalculate max HP, current HP, stats, shininess, gender, and Unown letter
        Mon.refreshStats(selectedMon, currentGame.data)

        mod.log:info(string.format("Applied %s DVs to %s!", profile.label, selectedMon.name))
      end
    })
    
    return menuItems
  end)

end
