return function(mod)
    -- Require the core Phone module from the engine
    local Phone = require("src.core.gen2.Phone")
    
    -- Phone.NUM_PHONE_CONTACTS is defined as 36 in the core engine.
    -- This guarantees enough capacity for every single available contact 
    -- in the game without needing to hardcode a magic number.
    Phone.CONTACT_LIST_SIZE = Phone.NUM_PHONE_CONTACTS
end
