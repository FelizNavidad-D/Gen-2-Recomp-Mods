return function(mod)
  -- =====================================================================
  -- De-Capitalization Mod (Ultimate Engine Edition - Gen 2)
  -- Intercepts static UI rendering, font encoding, and font width 
  -- calculations to catch absolutely all text, including Chrome wrappers.
  -- =====================================================================

  local okFont, Font = pcall(require, "src.render.Font")

  -- A strict safe-list of keywords that should NEVER be de-capitalized
  local keep_caps = {
    ["SEEN"] = true, ["OWNED"] = true,
    ["HP"] = true, ["PP"] = true, ["PC"] = true,
    ["TM"] = true, ["HM"] = true, ["OK"] = true,
    ["TV"] = true, ["CD"] = true, ["ID"] = true,
    ["KO"] = true, ["EXP"] = true, ["SS"] = true,
    ["VIP"] = true, ["PK"] = true, ["MN"] = true,
    ["UI"] = true, ["OT"] = true,
    
    -- Protects native Gen 2 macro tags so they render their single tiles correctly
    ["PO"] = true, ["KE"] = true, ["LV"] = true, 
    
    -- Protects specific stylized words to prevent awkward kerning next to macros
    ["GEAR"] = true,
    
    -- Gen 2 Card Flip mini-game abbreviations
    -- Note: "PO" (Poliwag) is already protected by the Pokegear macro above!
    ["PI"] = true, ["JI"] = true, ["OD"] = true 
  }

  local function smartCasing(str)
    if type(str) ~= "string" then return str end
    
    -- 1. Explicit UI Overrides & Accents
    str = str:gsub("POK[eéE]MON", "Pokémon")
    str = str:gsub("POK[eéE]DEX", "Pokédex")
    str = str:gsub("POK[eéE]BALL", "Pokéball")
    str = str:gsub("EXP%.ALL", "Exp. All")
    str = str:gsub("TM POUCH", "TM Pouch")
    
    -- 2. Smart Replace: Target ONLY whole words consisting entirely of uppercase letters.
    str = str:gsub("%f[%a](%u[%u'-]*%u)%f[%A]", function(word)
      if keep_caps[word] then return word end
      return word:sub(1,1) .. word:sub(2):lower()
    end)
    
    return str
  end

  -- =====================================================================
  -- CLASSIC GAME BOY TEXT INTERCEPTION
  -- =====================================================================
  if okFont and Font then
    
    -- 1. Intercept Font.encode (Catches all Typewriter, Dialogue, and Battle text)
    if not Font.__decap_encode_wrapped then
      Font.__decap_encode_wrapped = true
      local origEncode = Font.encode
      
      Font.encode = function(text, ...)
        if type(text) == "string" then
          text = smartCasing(text)
        end
        return origEncode(text, ...)
      end
    end

    -- 2. Intercept Font.width (Ensures Chrome.wrap calculates line breaks correctly)
    if not Font.__decap_width_wrapped then
      Font.__decap_width_wrapped = true
      local origWidth = Font.width
      
      Font.width = function(text, ...)
        if type(text) == "string" then
          text = smartCasing(text)
        end
        return origWidth(text, ...)
      end
    end

    -- 3. Intercept Font.draw (Catches all static UI Menus, Name tags, and Lists)
    if not Font.__decap_draw_wrapped then
      Font.__decap_draw_wrapped = true
      local origDraw = Font.draw
      local stringCache = {}

      Font.draw = function(text, x, y, ...)
        if type(text) == "string" then
          if stringCache[text] == nil then
            stringCache[text] = smartCasing(text)
          end
          text = stringCache[text]
        end
        return origDraw(text, x, y, ...)
      end
    end
  end

  -- =====================================================================
  -- MODERN UI / NATIVE LÖVE2D TEXT INTERCEPTION
  -- =====================================================================
  if love and love.graphics then
    if not _G.__decap_love_print_wrapped then
      _G.__decap_love_print_wrapped = true
      local modernStringCache = {}

      -- Intercept love.graphics.print
      local origLovePrint = love.graphics.print
      love.graphics.print = function(text, ...)
        if type(text) == "string" then
          if modernStringCache[text] == nil then
            modernStringCache[text] = smartCasing(text)
          end
          text = modernStringCache[text]
        end
        return origLovePrint(text, ...)
      end

      -- Intercept love.graphics.printf (used for wrapped text)
      local origLovePrintf = love.graphics.printf
      love.graphics.printf = function(text, ...)
        if type(text) == "string" then
          if modernStringCache[text] == nil then
            modernStringCache[text] = smartCasing(text)
          end
            text = modernStringCache[text]
        end
        return origLovePrintf(text, ...)
      end
    end
  end

  mod.log:info("De-Capitalization Mod: Ultimate Engine Edition (Gen 2) Loaded!")
end
