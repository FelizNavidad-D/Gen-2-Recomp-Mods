return function(mod)
  -- =====================================================================
  -- Team EXP Share (Gen 2 Modern Progressive + Happiness Bonus)
  -- 
  -- Fighters split 100% of the EXP pool. Bench shares 50%.
  -- Bypasses the vanilla EXP_SHARE held item tax.
  -- Pokemon with Max Happiness (255) gain the Lucky Egg effect (1.5x).
  -- =====================================================================

  -- -------------------------------------------------------------------
  -- 1. Happiness = Lucky Egg Bonus
  -- Intercept the individual EXP calculation for each Pokemon.
  -- -------------------------------------------------------------------
  mod.hooks:wrap("exp.gain", function(next, ctx)
    -- Max happiness in Gen 2 is 255. If they are maxed, grant the 1.5x boost!
    if (ctx.mon.happiness or 0) >= 255 then
      ctx.luckyEgg = true
    end
    
    -- Proceed with the engine's normal calculation using our modified context
    return next(ctx)
  end)

  -- -------------------------------------------------------------------
  -- 2. Party-Wide Distribution
  -- -------------------------------------------------------------------
  mod.hooks:wrap("battle.exp_award", function(next, ctx)
    local battle = ctx.battle
    local loser = ctx.loser
    local def = battle:speciesDef(loser)
    local party = battle.party
    
    local fighterIndices = ctx.recipients
    local numFighters = #fighterIndices
    
    local isFighter = {}
    for _, idx in ipairs(fighterIndices) do
      isFighter[idx] = true
    end
    
    local benchIndices = {}
    for i, mon in ipairs(party) do
      -- mon.isEgg natively protects eggs from gaining EXP
      if (mon.hp or 0) > 0 and not mon.isEgg and not isFighter[i] then
        benchIndices[#benchIndices + 1] = i
      end
    end
    
    -- QoL Patch: Consolidate EXP messages
    local origEmit = battle.emit
    local expMessagePrinted = false
    
    battle.emit = function(self, event)
      if event.kind == "experience" then
        if not expMessagePrinted then
          origEmit(self, { kind = "message", text = "Party gained EXP!" })
          expMessagePrinted = true
        end
        event.text = nil
        return origEmit(self, event)
      end
      return origEmit(self, event)
    end
    
    -- Distribute to fighters (100% split, ignore vanilla EXP_SHARE tax)
    if numFighters > 0 then
      battle:giveExperiencePass(loser, def, fighterIndices, numFighters, false)
    end
    
    -- Distribute to bench (50% split, ignore vanilla EXP_SHARE tax)
    if #benchIndices > 0 then
      battle:giveExperiencePass(loser, def, benchIndices, 2, false)
    end
    
    battle.emit = origEmit
  end)

  mod.log:info("team_exp_share: Gen 2 Modern Progressive (with Happiness bonus) active.")
end
