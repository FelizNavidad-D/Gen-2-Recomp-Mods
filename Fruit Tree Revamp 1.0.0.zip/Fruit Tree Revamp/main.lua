return function(mod)
  local Strings = require("src.core.Strings")

  -- Wrap the VM script execution to intercept opcodes before they run
  mod.hooks:wrap("script.command", function(vanilla, ctx, op, args, cmd)
    
    -- Only hijack the "fruittree" opcode
    if op == "fruittree" then
      local vm = ctx.vm

      -- 1. Identify the tree and the fruit it yields
      local tree = cmd.tree or (args and args[1]) or 0
      local item = vm.fruitTreeItemFn and vm.fruitTreeItemFn(tree) or 0
      local name = (item ~= 0 and vm.getItemNameFn and vm.getItemNameFn(item)) or "BERRY"

      vm.scriptVar = item
      vm:setStringBuffer(name)

      -- 2. Introductory text
      vm:showRaw(Strings("It's a fruit-\nbearing tree."))

      -- Trigger the daily reset check (refills trees if it's a new day)
      if vm.fruitTreeResetFn then vm.fruitTreeResetFn() end

      -- NOTE: We are entirely skipping the `vm.fruitTreePickedFn` check here. 
      -- This is what allows infinite harvests!

      -- 3. Calculate 1-7 random yield
      local qty = math.random(1, 7)
      vm:showRaw(Strings("Hey! It's\n" .. qty .. " " .. name .. "(s)!"))

      -- 4. Give the items
      local ok = true
      -- vm.giveItemFn natively accepts our custom quantity
      if vm.giveItemFn then ok = vm.giveItemFn(item, qty) ~= false end
      vm.scriptVar = ok and 1 or 0

      if not ok then
        vm:showRaw(Strings("But the PACK is\nfull…"))
        return "end" -- Stop script if the bag is full
      end

      vm:showRaw(Strings("Obtained\n" .. qty .. " " .. name .. "(s)!"))

      -- 5. Mark the tree as picked (so the save file is accurate, even though we ignore it) and play sounds
      if vm.fruitTreePickFn then vm.fruitTreePickFn(tree) end

      if vm.specialSoundFn then
        vm.specialSoundFn(item)
      elseif vm.playSoundFn then
        vm.playSoundFn(1) -- SFX_ITEM
      end

      local pocket = vm:pocketName(item)
      vm:showRaw(Strings("{PLAYER} put the\n" .. name .. "(s) in\nthe " .. pocket .. "."))

      -- 6. End the script branch so the vanilla command doesn't run twice
      return "end"
    end

    -- Pass all other opcodes (like 'writetext', 'applymovement', etc.) back to the vanilla handler
    return vanilla(ctx, op, args, cmd)
  end)
end
