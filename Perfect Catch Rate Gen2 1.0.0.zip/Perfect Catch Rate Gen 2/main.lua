return function(mod)
  
  -- List of Gen 1 and Gen 2 balls to upgrade
  local allBalls = {
    "POKE_BALL", "GREAT_BALL", "ULTRA_BALL", "SAFARI_BALL", "PARK_BALL",
    "FRIEND_BALL", "HEAVY_BALL", "LEVEL_BALL", "LURE_BALL", "FAST_BALL", 
    "MOON_BALL", "LOVE_BALL"
  }

  for _, ballId in ipairs(allBalls) do
    -- Patch the ball registry to include the Master Ball's guaranteed catch flags
    mod.content.balls:patch(ballId, { 
      autoCatch = true, 
      multiplier = math.huge 
    })
  end
  
  mod.log:info("Catch Rate Mod: Registry patched. All balls will now act as Master Balls.")

end
