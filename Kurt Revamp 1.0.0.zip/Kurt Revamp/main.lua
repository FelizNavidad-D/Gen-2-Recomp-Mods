return function(mod)
  local Vm = require("src.script.gen2.Vm")
  local Apricorns = require("src.core.gen2.Apricorns")
  local Strings = require("src.core.Strings")
  local Bag = require("src.inventory.Bag")

  Vm.SPECIALS["SelectApricornForKurt"] = function(vm)
    local save = vm.specials.save and vm.specials.save()
    local data = vm.specials.data and vm.specials.data()
    local inventory = save and save.inventory or {}

    -- 1. Read the player's choice from the vanilla menu (already on screen!)
    local choiceIndex = vm.scriptVar
    local chosenApricorn = Apricorns.select(inventory, choiceIndex)

    -- If the player canceled or had no Apricorns
    if not chosenApricorn then
      vm.scriptVar = 0
      return
    end

    local maxQty = inventory[chosenApricorn] or 0
    local qtyToGive = 1

    local itemDef = data and data.items and data.items[chosenApricorn]
    local name = (itemDef and itemDef.name) or chosenApricorn

    -- 2. Ask to craft. This acts as a roadblock to prevent A-mashing.
    if maxQty > 1 then
      -- vm:showRaw with 'true' keeps the text box open under the YES/NO prompt
      vm:showRaw(Strings("You have " .. maxQty .. " " .. name .. "s.\nCraft them all?"), true)
      local craftAll = coroutine.yield({ kind = "yesorno" })
      if craftAll then
        qtyToGive = maxQty
      end
    else
      vm:showRaw(Strings("Craft a ball from\nyour " .. name .. "?"), true)
      local craftOne = coroutine.yield({ kind = "yesorno" })
      if not craftOne then
        vm.scriptVar = 0
        return
      end
    end

    -- 3. Calculate balls (1-3 balls per Apricorn)
    local ballType = Apricorns.ballFor(chosenApricorn)
    local totalBalls = 0
    for _ = 1, qtyToGive do
      totalBalls = totalBalls + math.random(1, 3)
    end

    -- 4. Update Inventory
    local left = inventory[chosenApricorn] - qtyToGive
    inventory[chosenApricorn] = left > 0 and left or nil
    Bag.add(save, ballType, totalBalls, data)

    -- 5. Show success text
    local ballDef = data and data.items and data.items[ballType]
    local ballName = (ballDef and ballDef.name) or ballType
    
    -- vm:showRaw yields a text box that naturally requires an 'A' press to close
    vm:showRaw(Strings("Kurt worked lightning\nfast! Received " .. totalBalls .. "\n" .. ballName .. "(s)!"))

    -- 7. Kill the vanilla script completely so he doesn't complain or lock up
    vm.aborted = true
  end
end
