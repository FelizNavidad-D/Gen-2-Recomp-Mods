return function(mod)
  -- =====================================================================
  -- CORE REQUIRES 
  -- =====================================================================
  local Growth = require("src.pokemon.Growth")
  local Stats = require("src.pokemon.Stats")
  local Font = require("src.render.Font")
  local HudTiles = require("src.render.HudTiles")
  local Sound = require("src.core.Sound")
  local Strings = require("src.core.Strings")
  
  -- Protected requires for modules that might not exist in all engine versions
  local ok_monops, MonOps = pcall(require, "src.pokemon.MonOps")
  local ok_event, EventRegistry = pcall(require, "src.world.EventRegistry")

  -- ==========================================
  -- ENGINE LIMIT REMOVAL (MAX_LEVEL OVERRIDE)
  -- ==========================================
  pcall(function() require("src.battle.gen2.Mon").MAX_LEVEL = 255 end)
  pcall(function() require("src.pokemon.Pokemon").MAX_LEVEL = 255 end)

  -- ==========================================
  -- VISUAL FIX: 3-DIGIT LEVEL SQUISH
  -- ==========================================
  -- Intercept the native text renderers to drop the ":L" (<LV>) prefix 
  -- whenever a Pokemon is Level 100 or higher, freeing up a UI tile!
  
  pcall(function()
      local Font = require("src.render.Font")
      if not Font.__level_fix_wrapped then
          Font.__level_fix_wrapped = true
          local orig_draw = Font.draw
          Font.draw = function(text, x, y, ...)
              -- If the string contains "<LV>" followed by 3+ digits, strip the "<LV>"
              if type(text) == "string" and string.find(text, "<LV>", 1, true) then
                  text = string.gsub(text, "<LV>(%d%d%d+)", "%1")
              end
              return orig_draw(text, x, y, ...)
          end
      end
  end)

  pcall(function()
      local Chrome = require("src.ui.gen2.Chrome")
      if not Chrome.__level_fix_wrapped then
          Chrome.__level_fix_wrapped = true
          local orig_print = Chrome.print
          -- Chrome.print is responsible for rendering most Gen 2 menus
          Chrome.print = function(text, x, y, ...)
              if type(text) == "string" and string.find(text, "<LV>", 1, true) then
                  text = string.gsub(text, "<LV>(%d%d%d+)", "%1")
              end
              return orig_print(text, x, y, ...)
          end
      end
  end)

  -- =====================================================================
  -- GLOBAL SETTINGS & OPTIONS MENU INTEGRATION
  -- =====================================================================
  local C = _G.__LIMIT_BREAK_SETTINGS or {}
  _G.__LIMIT_BREAK_SETTINGS = C
  C.dynamic_caps = C.dynamic_caps == nil and true or C.dynamic_caps
  C.limit_break = C.limit_break == nil and true or C.limit_break

  if mod.options and mod.options.define then
    mod.options:define({
      {
        key = "dynamic_caps", type = "choice", label = "Dynamic Level Caps",
        choices = { { "Off", false }, { "On", true } },
        default = true
      },
      {
        key = "limit_break", type = "choice", label = "Level 100 Limit Break",
        choices = { { "Off", false }, { "On", true } },
        default = true
      }
    })
  end

  local function refreshOptions()
    if mod.options and mod.options.get then
      pcall(function()
        local dc = mod.options:get("dynamic_caps")
        if dc ~= nil then C.dynamic_caps = dc end
        local lb = mod.options:get("limit_break")
        if lb ~= nil then C.limit_break = lb end
      end)
    end
  end
  refreshOptions()

  mod.events:on("mod.options_changed", function(p)
    if p and p.mod == mod.id then
      if p.key == "dynamic_caps" then C.dynamic_caps = p.value end
      if p.key == "limit_break" then C.limit_break = p.value end
    end
  end)

  local ROW_TOGGLE = { { false, "OFF" }, { true, "ON" } }
  local function getModeIndex(val)
    return val and 2 or 1
  end

  local function persistOpt(game, key, val)
    local id = mod.id
    local opts = game and game.save and game.save.options
    if opts then
      opts.modOptions = opts.modOptions or {}
      opts.modOptions[id] = opts.modOptions[id] or {}
      opts.modOptions[id][key] = val
    end
    local loader = game and game.mods
    if loader then
      loader.modOptions = loader.modOptions or {}
      loader.modOptions[id] = loader.modOptions[id] or {}
      loader.modOptions[id][key] = val
    end
    if game and game.writeOptions then pcall(game.writeOptions, game) end
  end

  mod.hooks:wrap("ui.options.rows", function(nextFn, game, rows)
    local out = nextFn(game, rows)
    if type(out) ~= "table" then return out end
    
    out[#out + 1] = {
      id = mod.id .. ":dynamic_caps",
      label = "DYN. CAPS",
      value = function() return ROW_TOGGLE[getModeIndex(C.dynamic_caps)][2] end,
      step = function(g, dir) 
        C.dynamic_caps = not C.dynamic_caps
        persistOpt(g, "dynamic_caps", C.dynamic_caps)
        return true
      end,
    }

    out[#out + 1] = {
      id = mod.id .. ":limit_break",
      label = "LIMIT BREAK",
      value = function() return ROW_TOGGLE[getModeIndex(C.limit_break)][2] end,
      step = function(g, dir) 
        C.limit_break = not C.limit_break
        persistOpt(g, "limit_break", C.limit_break)
        return true
      end,
    }
    return out
  end)

  -- ==========================================
  -- CACHE THE ACTIVE GAME
  -- ==========================================
  
  local active_game = nil
  
  mod.events:on("save.loaded", function(ev)
    active_game = ev.game
  end)

  -- ==========================================
  -- DYNAMIC LEVEL CAP LOGIC
  -- ==========================================
  local function getDynamicCap()
      local useDynamicCaps = C.dynamic_caps
      local useLimitBreak = C.limit_break
      
      local maxAllowedLevel = useLimitBreak and 255 or 100
      if not useDynamicCaps then return maxAllowedLevel end

      -- Use the Gen2Compat facade to fetch the live game dynamically!
      local Game = require("src.core.Game")
      local save = Game.save
      if not save then return maxAllowedLevel end

      -- 1. Unconditionally unlock if Elite Four flags are found
      if save.events then
          if save.events["EVENT_BEAT_ELITE_4"] or 
             save.events["EVENT_BEAT_ELITE_4_RM"] or 
             save.events["EVENT_BEAT_CHAMPION_RIVAL"] or
             save.events["BEAT_ELITE_4"] then
              return maxAllowedLevel
          end
      end
      if save.flags and (save.flags["BEAT_ELITE_4"] or save.flags["EVENT_BEAT_ELITE_4"]) then
          return maxAllowedLevel
      end

      local cap = 15
      local badgeCount = 0

      -- 2. Safely check Gen 1 Inventory style
      if save.inventory then
          local legacyBadges = { 
              "BOULDERBADGE", "CASCADEBADGE", "THUNDERBADGE", "RAINBOWBADGE", 
              "SOULBADGE", "MARSHBADGE", "VOLCANOBADGE", "EARTHBADGE",
              "ZEPHYRBADGE", "HIVEBADGE", "PLAINBADGE", "FOGBADGE",
              "STORMBADGE", "MINERALBADGE", "GLACIERBADGE", "RISINGBADGE"
          }
          for _, badge in ipairs(legacyBadges) do
              if save.inventory[badge] then badgeCount = badgeCount + 1 end
          end
      end

      -- 3. Safely check Gen 2 Player table style
      if save.player then
          local p = save.player
          local johtoBadges = { "ZEPHYR", "HIVE", "PLAIN", "FOG", "MINERAL", "STORM", "GLACIER", "RISING" }
          local kantoBadges = { "BOULDER", "CASCADE", "THUNDER", "RAINBOW", "SOUL", "MARSH", "VOLCANO", "EARTH" }
          
          if type(p.badges) == "table" then
              for index, name in ipairs(johtoBadges) do
                  if p.badges[name] or p.badges[index] == true then badgeCount = badgeCount + 1 end
              end
          end
          if type(p.kantoBadges) == "table" then
              for index, name in ipairs(kantoBadges) do
                  if p.kantoBadges[name] or p.kantoBadges[index] == true then badgeCount = badgeCount + 1 end
              end
          end
      end

      if badgeCount >= 8 then return maxAllowedLevel end
      cap = cap + (badgeCount * 7)

      -- 4. Add +5 for Major Story Events
      if save.events then
          if save.events["EVENT_CLEARED_ROCKET_HIDEOUT"] then cap = cap + 5 end
          if save.events["EVENT_CLEARED_RADIO_TOWER"] then cap = cap + 5 end
          if save.events["EVENT_BEAT_ROCKET_HIDEOUT_GIOVANNI"] then cap = cap + 5 end
          if save.events["EVENT_BEAT_SILPH_CO_GIOVANNI"] then cap = cap + 5 end
      end

      return cap
  end

  -- ==========================================
  -- SAVE FILE SILENT CATCH-UP
  -- ==========================================
  mod.events:on("save.loaded", function(ev)
    local save = ev.save
    if not save then return end
    
    local game = ev.game
    local dynamicCap = getDynamicCap(game)
    
    local function restoreTrueLevel(list)
      if type(list) ~= "table" then return end
      for _, mon in ipairs(list) do
        local def = game.data.pokemon[mon.species]
        if def then
          local expectedLevel = Growth.levelForExp(def.growthRate, mon.exp, dynamicCap)
          if expectedLevel > 100 and mon.level < expectedLevel then
            mon.level = expectedLevel
            if mon.stats then
              local oldMax = mon.stats.hp
              mon.stats = Stats.calc(def, mon.level, mon.dvs, mon.statExp)
              if oldMax and oldMax > 0 then
                mon.hp = math.max(1, math.floor(mon.stats.hp * (mon.hp / oldMax)))
              else
                mon.hp = mon.stats.hp
              end
            else
              mon.stats = Stats.calc(def, mon.level, mon.dvs, mon.statExp)
              mon.hp = mon.stats.hp
            end
          end
        end
      end
    end
    
    restoreTrueLevel(save.party)
    for _, box in ipairs(save.boxes or {}) do
      restoreTrueLevel(box)
    end
    if save.daycare and save.daycare.mon then
      restoreTrueLevel({save.daycare.mon})
    end
  end)
  
  -- ==========================================
  -- HOOK: OVERRIDE THE GROWTH CURVE
  -- ==========================================
  mod.hooks:wrap("src.pokemon.Growth.levelForExp", function(nextFn, growthRate, exp, cap, rates)
    local dynamicCap = getDynamicCap()
    return nextFn(growthRate, exp, dynamicCap, rates)
  end)

  -- ==========================================
  -- HOOK: OVERRIDE BATTLE EXP (GEN 1 & GEN 2)
  -- ==========================================
  mod.hooks:wrap("src.battle.Experience.apply", function(nextFn, data, mon, defeatedDef, level, isTrainer, numParticipants, traded)
    data.constants = data.constants or {}
    local oldCap = data.constants.levelCap
    data.constants.levelCap = getDynamicCap()
    local levels, gained = nextFn(data, mon, defeatedDef, level, isTrainer, numParticipants, traded)
    data.constants.levelCap = oldCap
    return levels, gained
  end)

  -- Inject the dynamic cap directly into the Gen 2 engine with a safe pcall!
  pcall(function()
      mod.hooks:wrap("src.battle.gen2.Mon.gainExperience", function(nextFn, mon, amount, data)
          local Gen2Mon = require("src.battle.gen2.Mon")
          local cap = getDynamicCap()
          
          local oldMax = Gen2Mon.MAX_LEVEL
          Gen2Mon.MAX_LEVEL = cap
          
          local ok, result = pcall(nextFn, mon, amount, data)
          Gen2Mon.MAX_LEVEL = oldMax
          
          if not ok then error(result) end
          return result
      end)
  end)

  -- ==========================================
  -- EXP BANKING & SIPHON (GEN 2 CANDY JAR)
  -- ==========================================
  mod.hooks:wrap("exp.gain", function(origFn, ctx)
      local amount = origFn(ctx)
      
      -- Fetch the live save file securely
      local Game = require("src.core.Game")
      local save = Game.save
      if not save then return amount end

      local cap = getDynamicCap()
      save.exp_candy_jar = save.exp_candy_jar or 0

      -- 1. Enforce the Cap: Divert wasted EXP directly into the Jar
      if ctx.mon.level >= cap then
          if amount > 0 then
              save.exp_candy_jar = save.exp_candy_jar + amount
              -- Safely check for sayNext (some Gen 2 headless battle models lack it)
              if ctx.battle and type(ctx.battle.sayNext) == "function" and not ctx.mon._jarTextPrinted then
                  ctx.battle:sayNext(ctx.mon.name .. " is capped!\n" .. amount .. " EXP stored in Jar!")
                  ctx.mon._jarTextPrinted = true
              end
          end
          return 0 
      end

      -- 2. Calculate the exact max EXP using pure math, bypassing the engine's clamp
      local maxExpAllowed = math.huge
      local def = ctx.battle.data.pokemon[ctx.mon.species]
      if def and def.growthRate then
          local ok, Gen2Mon = pcall(require, "src.battle.gen2.Mon")
          if ok and Gen2Mon then
              local growth = Gen2Mon.growthFor(ctx.battle.data, def.growthRate)
              maxExpAllowed = Gen2Mon.experienceForLevel(growth, cap)
          else
              local Growth = require("src.pokemon.Growth")
              maxExpAllowed = Growth.expForLevel(def.growthRate, cap)
          end
      end

      local currentExp = ctx.mon.experience or ctx.mon.exp or 0
      local expRoom = maxExpAllowed - currentExp
      if expRoom < 0 then expRoom = 0 end

      -- 3. Pour the Jar if active
      local totalToGive = amount
      if save.jarActive and save.exp_candy_jar > 0 then
          totalToGive = amount + save.exp_candy_jar
          save.exp_candy_jar = 0
          save.jarActive = false 
          
          if ctx.battle and type(ctx.battle.sayNext) == "function" then
              pcall(function() require("src.core.Sound").play(ctx.battle.data, "Sfx_DexFanfare50_79") end)
              ctx.battle:sayNext("The CANDY JAR poured into " .. ctx.mon.name .. "!")
          end
      end

      -- 4. Clamp the EXP so it NEVER exceeds the level cap!
      if totalToGive > expRoom then
          local overflow = totalToGive - expRoom
          save.exp_candy_jar = save.exp_candy_jar + overflow
          totalToGive = expRoom
          
          if ctx.battle and type(ctx.battle.sayNext) == "function" then
              ctx.battle:sayNext("Level Cap reached!\n" .. overflow .. " EXP sent back to Jar!")
          end
      end

      return totalToGive
  end)

  -- ==========================================
  -- START MENU UI: THE CANDY JAR (GEN 2 TOGGLE)
  -- ==========================================
  mod.hooks:wrap("ui.start_menu.items", function(origFn, game, items)
      local list = origFn(game, items) or items
      if type(list) == "table" then
          local save = game and game.save
          if not save then return list end
          
          save.exp_candy_jar = save.exp_candy_jar or 0
          
          local insertIndex = #list
          for i, v in ipairs(list) do
              if v.id == "save" or v.value == "save" then insertIndex = i; break end
          end
          
          table.insert(list, insertIndex, {
              id = "candy_jar",
              label = "CANDY JAR",
              desc = { 
                  "Stored: " .. save.exp_candy_jar .. " EXP", 
                  save.jarActive and "Status: POURING NEXT BTL" or "Status: SEALED" 
              },
              onSelect = function(g)
                  if g.save.exp_candy_jar <= 0 then
                      pcall(function() require("src.core.Sound").play(g.data, "Sfx_Wrong") end)
                      return
                  end
                  
                  g.save.jarActive = not g.save.jarActive
                  pcall(function() require("src.core.Sound").play(g.data, "Sfx_ReadText2") end)
                  
                  if g.popScene then g:popScene() end
              end
          })
      end
      return list
  end)

  -- ==========================================
  -- HOOK: CRYSTAL 251 SUMMARY MENU EXP BAR
  -- ==========================================
  mod.hooks:wrap("src.ui.SummaryMenu.drawPage2", function(nextFn, self)
      if self.mon.level < 100 then
          return nextFn(self)
      end
      
      local orig_font_draw = Font.draw
      local orig_status_tile = HudTiles.statusTile
      
      Font.draw = function(text, x, y, ...)
          if y == 14 * 8 and x >= 48 then return 0 end 
          return orig_font_draw(text, x, y, ...)
      end
      
      HudTiles.statusTile = function(id, x, y, ...)
          if y == 14 * 8 and x >= 112 then return end 
          return orig_status_tile(id, x, y, ...)
      end
      
      local ok, err = pcall(nextFn, self)
      
      Font.draw = orig_font_draw
      HudTiles.statusTile = orig_status_tile
      if not ok then error(err) end
      
      local def = self.game.data.pokemon[self.mon.species]
      local dynamicCap = getDynamicCap(self.game)
      
      local nextExp = self.mon.level < dynamicCap 
          and (Growth.expForLevel(def.growthRate, self.mon.level + 1) - self.mon.exp) 
          or 0
      
      Font.draw(("%7d"):format(math.max(0, nextExp)), 64, 112)
      
      local targetLevel = math.min(dynamicCap, self.mon.level + 1)
      local tx = 136
      
      if targetLevel < 100 then
          HudTiles.statusTile(0x6E, tx, 112)
          tx = tx + 8
      end
      
      Font.draw(tostring(targetLevel), tx, 112)
  end)

  mod.log:info("Dynamic Level Caps, Limit Breaker & Candy Jar loaded successfully!")
end
