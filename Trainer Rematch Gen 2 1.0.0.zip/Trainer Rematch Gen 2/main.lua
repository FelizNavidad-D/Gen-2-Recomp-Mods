return function(mod)
  mod.log:info("Gen 2 Trainer Rematch Mod Loaded (Definitive Edition)")

  local Collision = package.loaded["src.world.Collision"] or require("src.world.Collision")
  local OverworldController = package.loaded["src.world.OverworldController"] or require("src.world.OverworldController")
  local TextBox = package.loaded["src.render.TextBox"] or require("src.render.TextBox")
  local ChoiceBox = package.loaded["src.ui.ChoiceBox"] or require("src.ui.ChoiceBox")

  mod.hooks:wrap("input.step", function(origFn, game)
    -- Anti-Mash Cooldown
    if game.world and game.world.__rematch_cooldown and game.world.__rematch_cooldown > 0 then
        game.world.__rematch_cooldown = game.world.__rematch_cooldown - 1
    end

    local isOverworldActive = (game.stack == nil or game.stack:top() == nil)
    local isCooldownFinished = (not game.world or not game.world.__rematch_cooldown or game.world.__rematch_cooldown == 0)

    if game.input:wasPressed("a") and isOverworldActive and isCooldownFinished and game.world and game.world.vm and not game.world.vm:running() then
      local p = game.world.player
      if not p then return origFn(game) end
      
      local tx, ty = Collision.target(p.cellX, p.cellY, p.facing)
      local npc = OverworldController.npcAtCell(tx, ty)
      if not npc or not npc.def then return origFn(game) end

      -- 1. Is it a Route Trainer?
      local routeFlag = npc.def.trainer and npc.def.trainer.event
      local isRouteTrainerDefeated = false
      if routeFlag then
          isRouteTrainerDefeated = OverworldController.trainerDefeated(npc)
      end

      -- 2. Is it a Gym Leader / Boss?
      local bossFlag = nil
      local isBossDefeated = false
      
      if not routeFlag then
          local scriptKey = npc.def.scriptKey
          local script = nil
          
          -- Safely resolve the script list to prevent Lua crashes
          if type(scriptKey) == "string" then
              script = game.world.vm.scripts[scriptKey]
          elseif type(scriptKey) == "table" then
              script = scriptKey
          end
          
          -- Scan the script for the 'checkevent' defeat flag and 'loadtrainer' battle command
          if type(script) == "table" then
              local tempFlag = nil
              local hasLoadTrainer = false
              for _, cmd in ipairs(script) do
                  if cmd.op == "checkevent" and not tempFlag then
                      tempFlag = cmd.event
                  elseif cmd.op == "loadtrainer" then
                      hasLoadTrainer = true
                      break
                  end
              end
              -- Verify they are actually a defeated boss
              if hasLoadTrainer and tempFlag then
                  bossFlag = tempFlag
                  if game.world.events and game.world.events.get then
                      isBossDefeated = game.world.events:get(bossFlag)
                  end
              end
          end
      end

      -- 3. Trigger the Rematch Prompt
      if isRouteTrainerDefeated or isBossDefeated then
          require("src.core.Sound").play(game.data, "Press_AB")
          
          game.stack:push(TextBox.new(game, "Ready for a rematch?\nChallenge them?", function()
              game.stack:push(ChoiceBox.new(game, function(yes)
                  if yes then
                      game.world.__rematch_cooldown = 30 
                      
                      -- A. Wipe the flag dynamically from live memory
                      local targetFlag = routeFlag or bossFlag
                      if targetFlag then
                          if game.world.events and game.world.events.set then
                              game.world.events:set(targetFlag, false)
                          end
                          if game.save and game.save.events then 
                              game.save.events[targetFlag] = nil 
                          end
                          mod.log:info("Trainer Rematch: Wiped Flag " .. tostring(targetFlag))
                      end
                      
                      -- B. Launch the native scripts natively
                      if routeFlag then
                          OverworldController.engageTrainer(npc)
                      elseif bossFlag then
                          game.world.vm.lastTalked = (npc.def.index or 0) + 1
                          game.world.vm:start(npc.def.scriptKey)
                      end
                  else
                      game.world.__rematch_cooldown = 15
                  end
              end))
          end))
          
          -- Swallow the A button to perform the "1-frame mute"
          return
      end
    end
    
    return origFn(game)
  end)
end
