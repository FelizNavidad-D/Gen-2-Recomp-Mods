return function(mod)
  mod.log:info("Gen 2 Trainer Rematch Mod Loaded (Dynamic Scaling Synergy)")

  local Collision = package.loaded["src.world.Collision"] or require("src.world.Collision")
  local OverworldController = package.loaded["src.world.OverworldController"] or require("src.world.OverworldController")
  local TextBox = package.loaded["src.render.TextBox"] or require("src.render.TextBox")
  local ChoiceBox = package.loaded["src.ui.ChoiceBox"] or require("src.ui.ChoiceBox")

  mod.hooks:wrap("input.step", function(origFn, game)
    -- Anti-Mash Cooldown
    if game.world and game.world.__rematch_cooldown and game.world.__rematch_cooldown > 0 then
        game.world.__rematch_cooldown = game.world.__rematch_cooldown - 1
    end

    local isOverworldActive = (game.stack == nil or game.stack:top() == nil)
    local isCooldownFinished = (not game.world or not game.world.__rematch_cooldown or game.world.__rematch_cooldown == 0)

    if game.input:wasPressed("a") and isOverworldActive and isCooldownFinished and game.world and game.world.vm and not game.world.vm:running() then
      local p = game.world.player
      
      if p then
        local tx, ty = Collision.target(p.cellX, p.cellY, p.facing)
        local npc = OverworldController.npcAtCell(tx, ty)
        
        if npc and OverworldController.trainerDefeated(npc) then
            
            require("src.core.Sound").play(game.data, "Press_AB")
            
            game.stack:push(TextBox.new(game, "Ready for a rematch?\nChallenge them?", function()
                game.stack:push(ChoiceBox.new(game, function(yes)
                    if yes then
                        game.world.__rematch_cooldown = 30 
                        
                        -- 1. Grab the exact event flag from the Gen 2 trainer object
                        local flag = npc.def and npc.def.trainer and npc.def.trainer.event
                        
                        -- Fallback for stationary encounters
                        if not flag then flag = npc.def and npc.def.event end 
                        
                        if flag then
                            -- 2. Use the engine's native method to clear the live memory array!
                            if game.world.events and game.world.events.set then
                                game.world.events:set(flag, false)
                            end
                            
                            -- 3. Clear it from the static save file
                            if game.save and game.save.events then 
                                game.save.events[flag] = nil 
                            end
                            
                            mod.log:info("Trainer Rematch: Safely Wiped Event Flag " .. tostring(flag) .. "!")
                        end
                        
                        -- 4. Trigger the vanilla interaction script natively
                        OverworldController.engageTrainer(npc)
                    else
                        game.world.__rematch_cooldown = 15
                    end
                end))
            end))
            
            return
        end
      end
    end
    
    return origFn(game)
  end)
end
