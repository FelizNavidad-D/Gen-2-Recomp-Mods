return function(mod)
  local Collision = package.loaded["src.world.Collision"] or require("src.world.Collision")
  
  mod.hooks:wrap("input.step", function(origFn, game)
    -- 1. Intercept the A button before the engine reads it
    if game.input:wasPressed("a") and game.world and game.world.vm and not game.world.vm:running() then
      local p = game.world.player
      if p then
        -- 2. Find the cell the player is facing
        local tx, ty = Collision.target(p.cellX, p.cellY, p.facing)
        
        -- 3. Find the NPC at that cell
        local npc = game.world:npcAt(tx, ty)
        
        if npc and npc.def then
            local txt = "SCAN RESULTS:<NEXT>"
            local found = false
            
            -- 4. Gen 2 trainer flags are often nested in npc.def.trainer
            local targetData = npc.def.trainer or npc.def
            
            for k, v in pairs(targetData) do
                if type(v) == "number" or type(v) == "string" then
                    local lowerK = string.lower(tostring(k))
                    -- Filter for the exact keys we need to build the Rematch Mod
                    if string.match(lowerK, "flag") or string.match(lowerK, "class") or string.match(lowerK, "script") then
                        txt = txt .. tostring(k) .. ": " .. tostring(v) .. "<NEXT>"
                        found = true
                    end
                end
            end
            
            if not found then txt = txt .. "No flag/class data found." end
            
            -- 5. Queue our dialogue box safely
            if mod.world then
                mod.world:queueScript({
                    { "text", txt }
                })
            end
            
            -- 6. Return immediately! This acts as the "1-frame mute" by swallowing the A button!
            return
        end
      end
    end
    
    return origFn(game)
  end)
end
