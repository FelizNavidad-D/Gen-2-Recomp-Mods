return function(mod)
  local Boxes = require("src.core.gen2.Boxes") --[span_2](start_span)[span_2](end_span)

  mod.hooks:wrap("script.command", function(vanilla, ctx, op, args, cmd)
    -- Hijack the script if Bill (Contact ID 3) is the active caller[span_3](start_span)[span_3](end_span)
    if ctx.vm.curPhoneCaller == 3 and (op == "farwritetext" or op == "writetext") then
      
      -- Ensure the custom sequence only executes once per call
      if not ctx.vm.billHijacked then
        ctx.vm.billHijacked = true
        
        local h = ctx.vm.specials or {}
        local record = h.save and h.save() --[span_4](start_span)[span_4](end_span)
        local nextBox = 0
        
        -- Query native Gen 2 box capacity[span_5](start_span)[span_5](end_span)
        if record then
          for i = 1, Boxes.NUM_BOXES do
            if Boxes.count(record, i) < Boxes.MONS_PER_BOX then
              nextBox = i
              break
            end
          end
        end
        
        if nextBox > 0 then
          ctx.vm:showRaw("Hi, <PLAYER>?\nIt's me, Bill!\n\nThanks for using\nmy Storage System.")
          ctx.vm:showRaw("That last #MON\novertaxed my\nsystems!")
          
          -- Pass 'true' to hold the text box open for the yesorno prompt[span_6](start_span)[span_6](end_span)
          ctx.vm:showRaw("Your current box is\nfull. Do you want\nme to switch you\nover to Box " .. nextBox .. "?", true)
          
          -- Yield the VM coroutine to draw the prompt[span_7](start_span)[span_7](end_span)
          local yes = coroutine.yield({ kind = "yesorno" })
          
          if yes then
            if record then Boxes.setCurrent(record, nextBox) end --[span_8](start_span)[span_8](end_span)
            
            ctx.vm:showRaw("SAVING… DON'T TURN\nOFF THE POWER.", true, 48)
            
            -- Execute native save and audio hooks[span_9](start_span)[span_9](end_span)
            if h.writeSave and h.writeSave() ~= false then
              if h.playSfxNamed then h.playSfxNamed("Sfx_Save") end
              local name = (record.player and record.player.name) or ""
              ctx.vm:showRaw(name .. " saved\nthe game.", true, 60)
            end
          else
            ctx.vm:showRaw("OK, I'll leave it\nalone. Give me a\ncall if you change\nyour mind.")
          end
        else
          ctx.vm:showRaw("Wow, you filled\na whole server.\n\nYou'll have to\nrelease #MON\nto make space.")
        end
        
        -- Clear the special call queue so the phone stops ringing[span_10](start_span)[span_10](end_span)
        if record and record.phone then record.phone.specialCall = 0 end
        
        -- Replicate the manual hangup sequence[span_11](start_span)[span_11](end_span)
        if ctx.vm.playSoundFn then ctx.vm.playSoundFn(107) end -- SFX_HANG_UP
        ctx.vm:showRaw("Click!")
        if ctx.vm.hangUpFn then ctx.vm.hangUpFn() end
        
        -- Terminate the vanilla script list[span_12](start_span)[span_12](end_span)
        return "end"
      end
      
      -- Suppress any subsequent vanilla text commands
      return "end"
    end
    
    -- Forward all other commands to the vanilla interpreter[span_13](start_span)[span_13](end_span)
    return vanilla(ctx, op, args, cmd)
  end)
end
