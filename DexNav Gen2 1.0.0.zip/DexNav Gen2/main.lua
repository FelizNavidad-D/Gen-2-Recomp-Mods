return function(mod)
  -- =====================================================================
  -- DexNav Grid UI Mod (High-Resolution Floating Panel & Full Color Icons)
  -- =====================================================================

  mod.options:define({
    { key = "modernUiStyle", label = "MODERN UI STYLE", type = "toggle", default = true, description = "Enable the Modern UI aesthetic for the DexNav (requires Gen1 Modern UI mod to be active)." }
  })

  local Font = require("src.render.Font")
  local Strings = require("src.core.Strings")
  local TextBox = require("src.render.TextBox")
  
  local Assets = require("src.render.Assets")
  local Sprites = require("src.pokemon.Sprites")
  local PartyMenu = require("src.ui.PartyMenu")
  local Map = require("src.world.Map")
  local BattleState = require("src.battle.BattleState")
  local Menu = require("src.ui.Menu")
  local Collision = require("src.world.Collision")

  -- ---------------------------------------------------------------------
  -- PART 1: Icon Rendering Helper Functions
  -- ---------------------------------------------------------------------
  local iconCache = {}
  local modernFonts = {}

  local function getObpIcon(path)
    if not (love.image and love.image.newImageData) then
      return love.graphics.newImage(Assets.resolve(path))
    end
    local id = Assets.imageData(path)
    
    id:mapPixel(function(_, _, r, g, b, a)
      local luma = 0.299 * r + 0.587 * g + 0.114 * b
      local v = 0
      if luma > 0.8 then v = 1
      elseif luma > 0.5 then v = 170 / 255
      elseif luma > 0.2 then v = 85 / 255
      else v = 0 end
      return v, v, v, a
    end)
    return love.graphics.newImage(id)
  end

  local function isTrueColorIcon(game, species)
    local ok, PartyMenuCheck = pcall(require, "src.ui.PartyMenu")
    if ok and PartyMenuCheck and PartyMenuCheck._uniqueMenuIconsTrueColorWrapped then
      return true
    end
    return false
  end

  local function getIconPath(game, species)
    local icons = game.data.gen2Icons or game.data.icons
    if not icons then return nil, nil end
    
    -- Gen 2 uses 'icons.species', Gen 1 uses 'icons.bySpecies'
    local iconName = (icons.species and icons.species[species]) or (icons.bySpecies and icons.bySpecies[species])
    
    if not iconName then
        local def = game.data.pokemon and game.data.pokemon[species]
        iconName = def and def.icon
        if not iconName and def and def.dex and icons.byDex then
            iconName = icons.byDex[def.dex]
        end
    end
    
    local path
    if iconName and icons.icons then
        local entry = icons.icons[iconName]
        if type(entry) == "table" then
            path = entry.image or entry.path
        elseif type(entry) == "string" then
            path = entry
        end
    end
    
    local ok, Sprites = pcall(require, "src.pokemon.Sprites")
    if ok and Sprites and Sprites.iconPath then
        return Sprites.iconPath(game.data, {species=species}, path, { name = iconName }), iconName
    end
    
    return path, iconName
  end

  local function getHighResIconData(game, species)
      if species == "BALL" then
          local icons = game.data.gen2Icons or game.data.icons
          local ballPath = icons and icons.icons and (icons.icons["BALL"] or icons.icons["ball"])
          if not ballPath then return nil end
          local key = ballPath .. "#raw"
          if iconCache[key] == nil then
              local ok, img = pcall(love.graphics.newImage, Assets.resolve(ballPath))
              iconCache[key] = ok and img or false
          end
          return iconCache[key], true 
      end

      local iconPath, iconName = getIconPath(game, species)
      if not iconPath then return nil end
      
      local trueColor = false
      if type(iconPath) == "string" and (iconPath:find("icons_color") or iconPath:find("icons_gbc_red")) then
          trueColor = true
      end
      
      local key = trueColor and (iconPath .. "#raw") or (iconName and (iconPath .. "#obp") or iconPath)
      
      if iconCache[key] == nil then
         local ok, img
         if trueColor then
             ok, img = pcall(love.graphics.newImage, Assets.resolve(iconPath))
         elseif iconName then
             ok, img = pcall(getObpIcon, iconPath)
         else
             ok, img = pcall(love.graphics.newImage, Assets.resolve(iconPath))
         end
         iconCache[key] = ok and img or false
      end
      return iconCache[key], trueColor
  end

  local function getPrecoloredIcon(game, species)
      local iconPath, iconName = getIconPath(game, species)
      if not iconPath then return nil end

      local trueColor = false
      if type(iconPath) == "string" and (iconPath:find("icons_color") or iconPath:find("icons_gbc_red")) then
          trueColor = true
      end

      local key = trueColor and (iconPath .. "#raw") or (iconPath .. "#colored")
      if iconCache[key] == nil then
          if trueColor then
              local ok, img = pcall(love.graphics.newImage, Assets.resolve(iconPath))
              iconCache[key] = (ok and img) or false
          else
              local ok, id = pcall(love.image.newImageData, Assets.resolve(iconPath))
              if ok and id then
                  local pal = nil
                  local isGen2 = game.data.gen2Palettes ~= nil
                  
                  -- GEN 2 FIX: Use Gen 2's native Palettes module
                  if isGen2 then
                      local okPals, Palettes = pcall(require, "src.world.gen2.Palettes")
                      if okPals and Palettes then
                          pal = Palettes.monColors(game.data.gen2Palettes, species)
                      end
                  else
                      local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
                      if okFX and PaletteFX and PaletteFX.monPal then
                          pal = PaletteFX.monPal(game.data, species)
                      end
                      if not pal and game.data.palettes then
                          pal = game.data.palettes["CRYSTAL_251_" .. species]
                      end
                  end

                  if pal then
                      id:mapPixel(function(_, _, r, g, b, a)
                          local luma = 0.299 * r + 0.587 * g + 0.114 * b
                          local color = {1, 1, 1}
                          
                          if luma > 0.8 then color = pal[1] or color
                          elseif luma > 0.5 then color = pal[2] or color
                          elseif luma > 0.2 then color = pal[3] or color
                          else color = pal[4] or color end
                          
                          local cr = tonumber(color[1]) or 1
                          local cg = tonumber(color[2]) or 1
                          local cb = tonumber(color[3]) or 1
                          
                          if cr > 1 or cg > 1 or cb > 1 then 
                              cr = cr / 255; cg = cg / 255; cb = cb / 255 
                          end
                          
                          return cr, cg, cb, a
                      end)
                  else
                      id:mapPixel(function(_, _, r, g, b, a)
                          local luma = 0.299 * r + 0.587 * g + 0.114 * b
                          local v = 0
                          if luma > 0.8 then v = 1
                          elseif luma > 0.5 then v = 170 / 255
                          elseif luma > 0.2 then v = 85 / 255
                          else v = 0 end
                          return v, v, v, a
                      end)
                  end
                  local okImg, img = pcall(love.graphics.newImage, id)
                  iconCache[key] = (okImg and img) or false
              else
                  iconCache[key] = false
              end
          end
      end
      
      local result = iconCache[key]
      return result ~= false and result or nil
  end

  local function drawBoxIconScaled(game, mon, x, y, isSelected, blinkCounter, isSeen, scale, pOpac)
      if type(isSeen) == "number" then
          pOpac = scale
          scale = isSeen
          isSeen = true
      end
      if isSeen == nil then isSeen = true end

      local img, trueColor = getHighResIconData(game, mon.species)
      if not img then return end
      
      local alt = false
      local jumpY = 0
      if isSelected then 
          alt = math.floor(blinkCounter / 16) % 2 == 1 
          if alt then jumpY = -2 * scale end
      end
      
      local iw, ih = img:getDimensions()
      local _, iconName = getIconPath(game, mon.species)

      local frame = 0
      if PartyMenu.frameFor then
          local okFrame, res = pcall(PartyMenu.frameFor, iconName or "GENERIC", alt, ih)
          if okFrame then frame = res end
      end
      
      local isMirrored = false
      if iconName and PartyMenu.mirrorsIcon then
          local ok, res = pcall(PartyMenu.mirrorsIcon, iconName)
          if ok then isMirrored = res end
      end
      
      local paint = function()
          if isMirrored then
              local half = love.graphics.newQuad(0, frame * 16, 8, 16, iw, ih)
              love.graphics.draw(img, half, x, y + jumpY, 0, scale, scale)
              love.graphics.draw(img, half, x + 16 * scale, y + jumpY, 0, -scale, scale)
          elseif ih > 16 then
              local quad = love.graphics.newQuad(0, frame * 16, 16, 16, iw, ih)
              love.graphics.draw(img, quad, x, y + jumpY, 0, scale, scale)
          else
              love.graphics.draw(img, x, y + jumpY, 0, scale, scale)
          end
      end

      local isGen2 = game.data.gen2Palettes ~= nil
      local prevShader = love.graphics.getShader()

      if isSeen then
          love.graphics.setColor(1, 1, 1, pOpac or 1)
          if not trueColor and mon.species ~= "BALL" then
              if isGen2 then
                  -- GEN 2 FIX: Route the rendering through GbcPalette shader
                  local okPals, Palettes = pcall(require, "src.world.gen2.Palettes")
                  local okGbc, GbcPalette = pcall(require, "src.render.GbcPalette")
                  if okPals and okGbc and Palettes and GbcPalette then
                      local colors = Palettes.monColors(game.data.gen2Palettes, mon.species)
                      if colors and GbcPalette.available() then
                          GbcPalette.with(colors, paint)
                          return
                      end
                  end
              else
                  local ok, PaletteFX = pcall(require, "src.render.PaletteFX")
                  if ok and PaletteFX then
                      local pal = PaletteFX.monPal and PaletteFX.monPal(game.data, mon.species)
                      if not pal and game.data.palettes then
                          pal = game.data.palettes["CRYSTAL_251_" .. mon.species]
                      end
                      if pal then
                          local shader = PaletteFX.shader()
                          if shader then
                              pcall(PaletteFX.sendColors, shader, pal)
                              love.graphics.setShader(shader)
                              paint()
                              love.graphics.setShader(prevShader)
                              if PaletteFX.markTrueColor then
                                  PaletteFX.markTrueColor(x, y + jumpY, 16 * scale, 16 * scale)
                              end
                              return
                          end
                      end
                  end
              end
          end
      else
          love.graphics.setShader()
          love.graphics.setColor(0, 0, 0, 0.7 * (pOpac or 1))
      end
      
      paint()
      if prevShader then love.graphics.setShader(prevShader) end
  end

  local function getLargeSprite(game, species)
      if not species then return nil, false end
      local def = game.data.pokemon[species]
      if not def then return nil, false end
      
      local path = def.spriteFront
      local isTrueColor = false
      
      local ok, SpritesReq = pcall(require, "src.pokemon.Sprites")
      if ok and SpritesReq and type(SpritesReq.path) == "function" then
          local ctx = {kind = "summary", species = species, side = "front"}
          local p = SpritesReq.path(game.data, species, "front", ctx)
          if p then 
              path = p 
              isTrueColor = ctx.trueColor == true
          end
      end
      
      if not path then return nil, false end
      
      local okImg, img = pcall(love.graphics.newImage, Assets.resolve(path))
      if okImg and img then
          img:setFilter("nearest", "nearest")
          return img, isTrueColor
      end
      return nil, false
  end

  -- ---------------------------------------------------------------------
  -- PART 2: Encounter Data & Map Scanner
  -- ---------------------------------------------------------------------
  local function isSpeciesOwned(game, species)
    if not game or not game.save or not game.save.pokedex or not species then return false end
    
    -- Gen 2 uses 'caught', Gen 1 uses 'owned'
    local caughtTable = game.save.pokedex.caught or game.save.pokedex.owned
    if type(caughtTable) == "table" and caughtTable[species] then return true end
    
    local def = game.data and game.data.pokemon and game.data.pokemon[species]
    local dexNum = def and (def.dex or def.dexNum or def.number)
    if dexNum and type(caughtTable) == "table" and (caughtTable[dexNum] == true or caughtTable[tostring(dexNum)] == true) then
        return true
    end
    return false
  end  
  
  local function checkMapCapabilities(game, mapId)
    local ow = game.world or game.overworld
    local map = ow and ow.map
    if not map then return false, false end
    local hasGrass, hasWater = false, false
    local cellsX, cellsY = (map.def.width or 0) * 2, (map.def.height or 0) * 2
    for y = 0, cellsY - 1 do
      for x = 0, cellsX - 1 do
        if not hasGrass and map:isGrassCell(x, y) then hasGrass = true end
        if not hasWater and map:isWaterCell(x, y) then hasWater = true end
        if hasGrass and hasWater then break end
      end
      if hasGrass and hasWater then break end
    end
    
    local indoor = game.data.field and game.data.field.indoorEncounters
    local isIndoor = false
    if indoor and map.def.index and map.def.index >= indoor.firstIndoorMap and map.def.tileset ~= indoor.excludedTileset then
      isIndoor = true
    end

    local field = game.data.field or {}
    for _, rodDef in pairs(field.fishing or {}) do
      if type(rodDef) == "table" and rodDef.perMap and field[rodDef.perMap] and field[rodDef.perMap][mapId] then
        hasWater = true break
      end
    end
    return (hasGrass or isIndoor), hasWater
  end

  local function getMapEncounters(game)
    local ow = game.world or game.overworld
    local mapId = ow and ow.map and ow.map.id
    if not mapId then return {} end
    
    local _, canEncounterWater = checkMapCapabilities(game, mapId)
    local uniqueSpecies = {}
    local list = {}

    local function addSlot(species, level, method, rate)
      if species then
        local safeLevel = level or 5
        if not uniqueSpecies[species] then
          local isOwnedFlag = isSpeciesOwned(game, species)
          local entry = { 
            species = species, methods = {}, level = safeLevel, minLevel = safeLevel, maxLevel = safeLevel,
            owned = isOwnedFlag, caught = isOwnedFlag, isOwned = isOwnedFlag, hasCaught = isOwnedFlag
          }
          uniqueSpecies[species] = entry
          table.insert(list, entry)
        end
        uniqueSpecies[species].methods[method] = (uniqueSpecies[species].methods[method] or 0) + (rate or 100)
        
        if safeLevel < uniqueSpecies[species].minLevel then uniqueSpecies[species].minLevel = safeLevel end
        if safeLevel > uniqueSpecies[species].maxLevel then uniqueSpecies[species].maxLevel = safeLevel end
        if safeLevel > uniqueSpecies[species].level then uniqueSpecies[species].level = safeLevel end
      end
    end

    local encDef = game.data.gen2Encounters or game.data.encounters
    local isGen2 = encDef and (encDef.grass or encDef.fishGroups)

    if encDef then
      if isGen2 then
         -- ================================
         -- GEN 2 ENCOUNTER PARSING
         -- ================================
         
         if encDef.grass and encDef.grass[mapId] then
            local slots = encDef.grass[mapId].slots
            local chances = {30, 30, 20, 10, 5, 4, 1}
            if slots then
               for _, tod in ipairs({"MORN", "DAY", "NITE"}) do
                   if slots[tod] then
                       for i, slot in ipairs(slots[tod]) do
                           addSlot(slot.species, slot.level, "GRASS", chances[i] / 3)
                       end
                   end
               end
            end
         end
         
         if encDef.water and encDef.water[mapId] then
            local slots = encDef.water[mapId].slots
            local chances = {60, 30, 10}
            if slots then
               for i, slot in ipairs(slots) do
                   addSlot(slot.species, slot.level, "SURF", chances[i])
               end
            end
         end
         
         if canEncounterWater and encDef.fishGroups then
             local mapDef = ow.map.def
             local fishGroupId = mapDef.fishGroup or "FISHGROUP_POND"
             
             if fishGroupId ~= "FISHGROUP_NONE" then
                 local group = encDef.fishGroups[fishGroupId]
                 if group then
                     local rodMapping = { old = "OLD", good = "GOOD", super = "SUPER" }
                     for rodKey, methodStr in pairs(rodMapping) do
                         local rodList = group[rodKey]
                         if rodList then
                             for _, row in ipairs(rodList) do
                                 local chance = row.chance or 100
                                 local function extractFish(slotData)
                                     if slotData and slotData.species and slotData.species ~= "NO_ITEM" and slotData.species ~= 0 then
                                         addSlot(slotData.species, slotData.level or 5, methodStr, chance)
                                     end
                                 end
                                 
                                 if row.day then extractFish(row.day) end
                                 if row.nite then extractFish(row.nite) end
                                 if not row.day and not row.nite then
                                     if row.timeGroup and encDef.timeFishGroups then
                                         local tg = encDef.timeFishGroups[row.timeGroup]
                                         if tg and tg.day then extractFish(tg.day) end
                                         if tg and tg.nite then extractFish(tg.nite) end
                                     else
                                         extractFish(row)
                                     end
                                 end
                             end
                         end
                     end
                 end
             end
         end

      else
         -- ================================
         -- GEN 1 ENCOUNTER PARSING
         -- ================================
         local mapEnc = encDef[mapId]
         if mapEnc then
           local globalBuckets = (game.data.constants and game.data.constants.encounterBuckets) or { 51, 102, 141, 166, 191, 216, 229, 242, 253, 256 }
           local function processTerrain(sourceData, method)
             if not sourceData then return end
             local slots = sourceData.slots or (type(sourceData[1]) == "table" and sourceData)
             if slots and #slots > 0 then
               local activeBuckets = sourceData.buckets or globalBuckets
               for i, slot in ipairs(slots) do
                 local species = slot.species
                 local level = slot.level or slot.minLevel or 5
                 if species then
                   local prevB = (i == 1) and 0 or (activeBuckets[i-1] or 0)
                   local currB = activeBuckets[i] or 256
                   local weight = math.max(1, currB - prevB)
                   local ratePct = (weight / 256) * 100
                   addSlot(species, level, method, ratePct)
                 end
               end
             end
           end
           if mapEnc.grass then processTerrain(mapEnc.grass, "GRASS") end
           if mapEnc.dungeon then processTerrain(mapEnc.dungeon, "GRASS") end
           if mapEnc.cave then processTerrain(mapEnc.cave, "GRASS") end
           if mapEnc.water then processTerrain(mapEnc.water, "SURF") end
           if mapEnc.surf then processTerrain(mapEnc.surf, "SURF") end
         end

         if canEncounterWater then
            local field = game.data.field or {}
            for rodName, rodDef in pairs(field.fishing or {}) do
              local methodStr = "SUPER" 
              local rNameUpper = string.upper(tostring(rodName))
              if rNameUpper:find("OLD") then methodStr = "OLD" 
              elseif rNameUpper:find("GOOD") then methodStr = "GOOD" end
              
              local function addStatic(slot, defaultRate)
                 if slot and slot.species then addSlot(slot.species, slot.level, methodStr, slot.rate or defaultRate or 100) end
              end
              local function addStaticSlots(slots)
                 if type(slots) == "table" and #slots > 0 then 
                     local defaultR = 100 / #slots
                     for _, s in ipairs(slots) do addStatic(s, defaultR) end 
                 end
              end

              if rodDef.always then addStatic(rodDef.always, 100) end
              if rodDef.pool then addStaticSlots(rodDef.pool) end
              if rodDef.perMap and field[rodDef.perMap] then
                local mapGroup = field[rodDef.perMap][mapId]
                if mapGroup and type(mapGroup) == "table" then
                  local ver = game.version or (game.save and game.save.version) or game.data.version or game.data.gameVersion
                  if ver and type(ver) == "string" then
                     local vL, vU = string.lower(ver), string.upper(ver)
                     local vCaps = vL:gsub("^%l", string.upper)
                     mapGroup = mapGroup[vL] or mapGroup[vU] or mapGroup[vCaps] or mapGroup
                  end
                  if mapGroup.species then addStatic(mapGroup, 100) 
                  elseif mapGroup.slots then addStaticSlots(mapGroup.slots)
                  else
                    local speciesCount = 0
                    for _, item in pairs(mapGroup) do
                        if type(item) == "table" and item.species then speciesCount = speciesCount + 1 end
                    end
                    local splitRate = speciesCount > 0 and (100 / speciesCount) or 100
                    for _, item in pairs(mapGroup) do
                      if type(item) == "table" then
                        if item.species then addStatic(item, splitRate) 
                        else addStaticSlots(item.slots or item) end
                      end
                    end
                  end
                end
              end
            end
         end
      end
    end
    return list, mapId
  end

  -- ---------------------------------------------------------------------
  -- PART 3: Native Target Spawner
  -- ---------------------------------------------------------------------
  local function getPlayerCell(Game)
    local ow = Game.world or Game.overworld
    if ow and ow.player and ow.player.cellX and ow.player.cellY then return ow.player.cellX, ow.player.cellY end
    return Game.save.x or 0, Game.save.y or 0
  end

  local function safeDespawnDexNavTarget(Game)
    local ow = Game.world or Game.overworld
    local targetId = Game._dexNavTargetId
    if not targetId or not ow then return end
    if ow.interacting and ow.interacting.id == targetId then ow.interacting = nil end
    if ow.removeRuntimeObject then pcall(function() ow:removeRuntimeObject(targetId, "DexNav") end) end
    Game._dexNavTargetId = nil
    Game._dexNavTargetMapId = nil
  end

  local function getHabitatType(game, species)
    local encs = getMapEncounters(game)
    local hasWater, hasGrass = false, false
    for _, enc in ipairs(encs) do
      if enc.species == species then
        if enc.methods["SURF"] or enc.methods["OLD"] or enc.methods["GOOD"] or enc.methods["SUPER"] then hasWater = true end
        if enc.methods["GRASS"] then hasGrass = true end
        break
      end
    end
    if not hasWater and not hasGrass then hasGrass = true end
    return hasWater, hasGrass
  end

  local function isValidTile(game, map, tx, ty, hasWater, hasGrass)
    local indoor = game.data.field and game.data.field.indoorEncounters
    local isIndoor = indoor and map.def.index and map.def.index >= indoor.firstIndoorMap and map.def.tileset ~= indoor.excludedTileset
    local isWaterTile = map:isWaterCell(tx, ty)
    local isGrassTile = map:isGrassCell(tx, ty)
    if hasWater and not hasGrass then return isWaterTile
    elseif hasGrass and not hasWater then return isGrassTile or (isIndoor and not isWaterTile)
    else return isGrassTile or isWaterTile or (isIndoor and not isWaterTile) end
  end

  local function spawnDexNavEncounter(Game, species, level)
    local ow = Game.world or Game.overworld
    if not ow or not ow.map then return end
    
    if Game._dexNavTargetId then safeDespawnDexNavTarget(Game) end
    
    local px, py = getPlayerCell(Game)
    local candidates = {}
    local hasW, hasG = getHabitatType(Game, species)
    
    for dy = -6, 6 do
      for dx = -6, 6 do
        local tx, ty = px + dx, py + dy
        if isValidTile(Game, ow.map, tx, ty, hasW, hasG) and (math.abs(dx) > 1 or math.abs(dy) > 1) then
          local canExistHere = ow.map:isWalkableCell(tx, ty) or ow.map:isWaterCell(tx, ty)
          if canExistHere and not Collision.occupied(ow.entities, tx, ty) then
            table.insert(candidates, {x = tx, y = ty})
          end
        end
      end
    end
    
    if #candidates > 0 then
      local chosen = candidates[math.random(#candidates)]
      
      local objDef = { 
          sprite = "SPRITE_POKE_BALL", 
          x = chosen.x, 
          y = chosen.y,
          dexNavSpecies = species,
          dexNavLevel = level,
          dexNavHasWater = hasW,
          dexNavHasGrass = hasG,
          scriptKey = "DEXNAV_DUMMY", -- Forces Gen 2 engine to emit an "npc" interaction!
          runtime = true,
          owner = "DexNav" 
      }
      
      local npcId = ow:addRuntimeObject(ow.map.id, objDef, "DexNav")
      local iconPath, iconName = getIconPath(Game, species)
      
      local targetNpc
      for _, n in ipairs(ow.npcs) do
          if n.def and n.def.runtime and n.def.owner == "DexNav" then
              targetNpc = n
              n.id = npcId 
              break
          end
      end

      if targetNpc then
          targetNpc.px = chosen.x * 16
          targetNpc.py = chosen.y * 16
          targetNpc.cellX = chosen.x
          targetNpc.cellY = chosen.y

          if iconPath then
             if targetNpc.setSpriteDef then
                 targetNpc:setSpriteDef({ image = iconPath, frames = 2, walker = true, trueColor = true })
                 if ow.applySpritePalette then ow:applySpritePalette(targetNpc) end
             else
                 targetNpc.sprite.def = { image = iconPath, frames = 2, walker = true, trueColor = true }
             end
             
             targetNpc.sprite.resolveImage = function()
                 return getPrecoloredIcon(Game, species)
             end
          end

          -- Gen 2 uses ox, oy, scale for its rendering space!
          targetNpc.draw = function(n_self, ox, oy, scale)
            scale = scale or 1
            n_self.animCounter = (n_self.animCounter or 0) + 1
            local bob = (n_self.moving or n_self.marching) and (math.floor((n_self.progress or 0) / 4) % 2 == 0 and 1 or 0) or 0
            local drawSpecies = n_self.def and n_self.def.dexNavSpecies or n_self.dexNavSpecies
            
            -- Calculate precise screen position based on Gen 2 camera offsets
            local drawX = ox + (n_self.px * scale)
            local drawY = oy + (n_self.py * scale) - (4 * scale) - (bob * scale)
            
            drawBoxIconScaled(Game, {species=drawSpecies}, drawX, drawY, true, n_self.animCounter, true, scale, 1)
          end
          
          local orig_pose = targetNpc.pose
          targetNpc.pose = function(self)
            local sprite, pos_x, pos_y
            if orig_pose then
                sprite, pos_x, pos_y = orig_pose(self)
            else
                sprite, pos_x, pos_y = self.sprite, self.px, self.py
            end
            self.animCounter = (self.animCounter or 0) + 1
            local phase = math.floor(self.animCounter / 20) % 2
            return sprite, pos_x, pos_y, "down", phase, false
          end
      end
      
      Game._dexNavTargetId = npcId
      Game._dexNavTargetMapId = ow.map.id 
      require("src.core.Sound").playCry(Game.data, species)
    else
      require("src.core.Sound").play(Game.data, "Denied")
      Game.stack:push(TextBox.new(Game, Strings("No suitable habitat\nnearby for this!\f")))
    end
  end

  local function startDexNavBattle(Game, ow, targetNpc)
    local species = targetNpc.def and targetNpc.def.dexNavSpecies or targetNpc.dexNavSpecies
    local level = targetNpc.def and targetNpc.def.dexNavLevel or targetNpc.dexNavLevel
    
    targetNpc.frozen = true
    if ow.interacting and ow.interacting.id == targetNpc.id then ow.interacting = nil end
    require("src.core.Sound").play(Game.data, "Collision")
    
    local isGen2 = Game.world ~= nil
    
    if isGen2 then
        local gen2World = Game.world
        local Mon = require("src.battle.gen2.Mon")
        local mon = Mon.new(Game.data, species, level)
        -- The Gen 2 startBattle natively handles the wipe transition automatically.
        gen2World:startBattle({ wild = mon })
    else
        local battle = BattleState.newWild(Game, species, level)
        local ghost = Map.ghostBattles(ow.map.def)
        if ghost and not (ghost.unlessItem and Game.save.inventory[ghost.unlessItem]) then battle:makeGhost() end
        if Game.save.safari and Map.inRegion(ow.map.def, "SAFARI", "SAFARI_ZONE") then battle:makeSafari(Game.save.safari) end
        
        battle.onFinish = function(result) 
            pcall(function() safeDespawnDexNavTarget(Game) end)
            if ow.afterBattle then ow:afterBattle(result, battle) end
        end
        ow:pushBattle(battle)
    end
  end

  -- ---------------------------------------------------------------------
  -- PART 4: Custom DexNav Grid Class
  -- ---------------------------------------------------------------------
  local activeDexNav = nil
  local DexNavGrid = {}
  DexNavGrid.__index = DexNavGrid

  function DexNavGrid.new(game, encounterData, mapId)
    local self = setmetatable({}, DexNavGrid)
    self.game = game
    self.boxData = encounterData
    self.mapId = mapId
    self.index = 1
    self.blink = 0
    self.isOpaque = false 
    self.isDexNavGrid = true
    self.subMenuOpen = false
    self.subMenuIndex = 1
    return self
  end

  function DexNavGrid:update(dt)
    activeDexNav = self
    self.blink = (self.blink + 1) % 320
    local input = self.game.input

    local forceClassic = mod.options:get("modernUiStyle") == false
    local modernMod = mod.find and mod.find("gen1_modern_ui")
    local opts = self.game.save and self.game.save.options and self.game.save.options.modOptions and self.game.save.options.modOptions["gen1_modern_ui"] or {}
    local isModern = modernMod and opts.menuUi ~= false and not forceClassic
    
    if isModern and self.subMenuOpen then
        if input:wasPressed("b") then
            require("src.core.Sound").play(self.game.data, "Press_AB")
            self.subMenuOpen = false
        elseif input:wasPressed("up") then
            self.subMenuIndex = self.subMenuIndex > 1 and self.subMenuIndex - 1 or 4
        elseif input:wasPressed("down") then
            self.subMenuIndex = self.subMenuIndex < 4 and self.subMenuIndex + 1 or 1
        elseif input:wasPressed("a") then
            require("src.core.Sound").play(self.game.data, "Press_AB")
            local mon = self.boxData[self.index]
            if self.subMenuIndex == 1 then 
                while self.game.stack:top() and not self.game.stack:top().isOverworld do self.game.stack:pop() end
                activeDexNav = nil
                spawnDexNavEncounter(self.game, mon.species, mon.level)
            elseif self.subMenuIndex == 2 then
                self.game.save.dexNavReg = { species = mon.species, level = mon.level }
                local def = self.game.data.pokemon[mon.species]
                require("src.core.Sound").play(self.game.data, "Save")
                self.subMenuOpen = false
                self.game.stack:pop() 
                self.game.stack:push(TextBox.new(self.game, Strings("%s registered\nto SELECT!\f", def.name)))
            elseif self.subMenuIndex == 3 then
                require("src.ui.Screens").push(self.game, "DexEntryMenu", mon.species)
            elseif self.subMenuIndex == 4 then
                self.subMenuOpen = false
            end
        end
        return 
    end

    if input:wasPressed("b") then
      require("src.core.Sound").play(self.game.data, "Press_AB")
      activeDexNav = nil
      self.game.stack:pop()
      return
    end

    if input:wasPressed("start") then
      require("src.core.Sound").play(self.game.data, "Press_AB")
      local NamingScreen = require("src.ui.NamingScreen")
      self.game.stack:push(NamingScreen.new(self.game, {
        title = "SEARCH AREA",
        default = "",
        maxLen = 10,
        onDone = function(searchText)
          if not searchText or searchText == "" then return end
          local searchUpper = searchText:upper()
          local found = false
          for i = 1, 20 do
            local mon = self.boxData[i]
            if mon then
               local def = self.game.data.pokemon[mon.species]
               local monName = (def and def.name or mon.species):upper()
               if monName:find(searchUpper) then
                  self.index = i
                  found = true
                  require("src.core.Sound").play(self.game.data, "Save")
                  break
               end
            end
          end
          if not found then
             require("src.core.Sound").play(self.game.data, "Denied")
             self.game.stack:push(TextBox.new(self.game, "That POKéMON isn't\nin this area!\f"))
          end
        end
      }))
      return
    end
    
    if input:wasPressed("a") then
      local mon = self.boxData[self.index]
      local dex = self.game.save.pokedex
      
      if mon and dex and dex.seen[mon.species] then
        require("src.core.Sound").play(self.game.data, "Press_AB")
        if isModern then
            self.subMenuOpen = true
            self.subMenuIndex = 1
        else
            local subMenu = Menu.new(self.game, {
              { label = "SEARCH", onSelect = function()
                  while self.game.stack:top() and not self.game.stack:top().isOverworld do self.game.stack:pop() end
                  activeDexNav = nil
                  spawnDexNavEncounter(self.game, mon.species, mon.level)
              end },
              { label = "REGISTER", onSelect = function()
                  self.game.save.dexNavReg = { species = mon.species, level = mon.level }
                  local def = self.game.data.pokemon[mon.species]
                  require("src.core.Sound").play(self.game.data, "Save")
                  activeDexNav = nil
                  self.game.stack:pop() 
                  self.game.stack:push(TextBox.new(self.game, Strings("%s registered\nto SELECT!\f", def.name)))
              end },
              { label = "DEX", keepOpen = true, onSelect = function()
                  require("src.ui.Screens").push(self.game, "DexEntryMenu", mon.species)
              end },
              { label = "CANCEL" }
            }, { tx = 11, ty = 6, tw = 9, th = 10, noSound = true })
            subMenu.boxData = true 
            self.game.stack:push(subMenu)
        end
      else
        require("src.core.Sound").play(self.game.data, "Collision")
      end
      return
    end

    if input:wasPressed("up") then
      self.index = self.index - 5
      if self.index < 1 then self.index = self.index + 20 end
    elseif input:wasPressed("down") then
      self.index = self.index + 5
      if self.index > 20 then self.index = self.index - 20 end
    elseif input:wasPressed("left") then
      if self.index % 5 == 1 then self.index = self.index + 4 else self.index = self.index - 1 end
    elseif input:wasPressed("right") then
      if self.index % 5 == 0 then self.index = self.index - 4 else self.index = self.index + 1 end
    end
  end

  function DexNavGrid:draw()
    local opts = self.game.save and self.game.save.options and self.game.save.options.modOptions and self.game.save.options.modOptions["gen1_modern_ui"] or {}
    local forceClassic = mod.options:get("modernUiStyle") == false
    local modernMod = mod.find and mod.find("gen1_modern_ui")
    local isModern = modernMod and opts.menuUi ~= false and not forceClassic
    
    if isModern then
        local target = love.graphics.getCanvas()
        if target then love.graphics.clear(0, 0, 0, 0) end
        return
    end

    local ok, err = pcall(function()
      local cr, cg, cb, ca = love.graphics.getColor()
      love.graphics.setColor(1, 1, 1, 0.40)
      love.graphics.rectangle("fill", 0, 0, 160, 144)
      love.graphics.setColor(cr, cg, cb, ca)
      
      local prev_translucent = Font.__translucent_active
      Font.__translucent_active = true

      Font.drawBox(0, 0, 20, 18)
      local dex = self.game.save.pokedex or {}
      local dexSeen = dex.seen or {}
      local dexOwned = dex.owned or {}

      for i = 1, 20 do
        local col = ((i - 1) % 5)
        local row = math.floor((i - 1) / 5)
        local x = col * 32
        local y = row * 24
        local mon = self.boxData[i]

        -- NEW CURSOR LOGIC: Draws a clean text box frame under the selected icon!
        if i == self.index then
          Font.drawBox(col * 4, row * 3, 4, 3)
        end

        if mon then
          local def = self.game.data.pokemon[mon.species] or {}
          local dexNum = def.dex
          local isSeen = dexSeen[mon.species] or (dexNum and (dexSeen[dexNum] or dexSeen[tostring(dexNum)]))
          drawBoxIconScaled(self.game, mon, x + 8, y + 4, i == self.index, self.blink, isSeen, 1, 1)
        else
          love.graphics.setColor(0.6, 0.6, 0.6, 1)
          love.graphics.rectangle("fill", x + 12, y + 11, 8, 2)
        end
      end

      local mapName = (self.mapId or "UNKNOWN"):gsub("_", " ")
      if Font.width(mapName) > 144 then
        while string.len(mapName) > 0 and Font.width(mapName .. "...") > 144 do mapName = string.sub(mapName, 1, -2) end
        mapName = mapName .. "..."
      end
      
      local mapNameWidth = Font.width(mapName)
      local mapNameX = math.floor((160 - mapNameWidth) / 2)
      
      love.graphics.setScissor(0, 96, mapNameX - 4, 8)
      Font.drawBox(0, 12, 20, 6)
      love.graphics.setScissor(mapNameX + mapNameWidth + 4, 96, 160, 8)
      Font.drawBox(0, 12, 20, 6)
      love.graphics.setScissor()
      
      local hoveredMon = self.boxData[self.index]
      
      love.graphics.setColor(0, 0, 0, 1)
      Font.draw(mapName, mapNameX, 96)
      
      if hoveredMon then
        local def = self.game.data.pokemon[hoveredMon.species] or {}
        local dexNum = def.dex
        
        local isSeen = dexSeen[hoveredMon.species] or (dexNum and (dexSeen[dexNum] or dexSeen[tostring(dexNum)]))
        local isOwned = hoveredMon.owned or hoveredMon.caught or dexOwned[hoveredMon.species] or (dexNum and (dexOwned[dexNum] or dexOwned[tostring(dexNum)]))

        if isSeen then
          Font.draw(Strings("%s", def.name or hoveredMon.species), 8, 112)
          if isOwned then
            local icons = self.game.data.icons or {}
            local iconDefs = icons.icons or {}
            local ballEntry = iconDefs["BALL"] or iconDefs["ball"]
            local ballPath = type(ballEntry) == "table" and (ballEntry.image or ballEntry.asset or ballEntry.path) or ballEntry
            
            if ballPath and type(ballPath) == "string" then
                local key = ballPath .. "#obp"
                if iconCache[key] == nil then
                    local okIcon, img = pcall(getObpIcon, ballPath)
                    iconCache[key] = okIcon and img or false
                end
                local img = iconCache[key]
                if img then
                    love.graphics.setColor(1, 1, 1, 1)
                    local prevShader = love.graphics.getShader()
                    local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
                    if okFX and PaletteFX and PaletteFX.monPal then
                        local pal = PaletteFX.monPal(self.game.data, "VOLTORB")
                        local shader = PaletteFX.shader()
                        if shader and pal then
                            pcall(PaletteFX.sendColors, shader, pal)
                            love.graphics.setShader(shader)
                        end
                    end
                    local iw, ih = img:getDimensions()
                    local frame = ih > 16 and PartyMenu.frameFor("BALL", false, ih) or 0
                    if ih > 16 then love.graphics.draw(img, love.graphics.newQuad(0, frame * 16, 16, 16, iw, ih), 8, 124)
                    else love.graphics.draw(img, 8, 124) end
                    love.graphics.setShader(prevShader)
                    if okFX and PaletteFX and PaletteFX.markTrueColor then
                        PaletteFX.markTrueColor(8, 124, 16, 16)
                    end
                    love.graphics.setColor(0, 0, 0, 1)
                end
            end
          end
        else
          Font.draw(Strings("?????"), 8, 112)
        end

        local m = hoveredMon.methods or {}
        local displayData = {}
        local function formatRate(r)
            local val = math.floor((tonumber(r) or 0) + 0.5)
            if val > 100 then val = 100 end 
            if val == 0 and (tonumber(r) or 0) > 0 then return "<1%" end
            return val .. "%"
        end

        if m["GRASS"] then table.insert(displayData, { method = "Grass", rate = formatRate(m["GRASS"]) }) end
        if m["SURF"]  then table.insert(displayData, { method = "Surf", rate = formatRate(m["SURF"]) }) end
        if m["OLD"]   then table.insert(displayData, { method = "Old", rate = formatRate(m["OLD"]) }) end
        if m["GOOD"]  then table.insert(displayData, { method = "Good", rate = formatRate(m["GOOD"]) }) end
        if m["SUPER"] then table.insert(displayData, { method = "Super", rate = formatRate(m["SUPER"]) }) end

        if #displayData > 0 then
          local currentIndex = 1
          if #displayData > 1 then
            local cycleFrames = 100 
            currentIndex = (math.floor((tonumber(self.blink) or 0) / cycleFrames) % #displayData) + 1
          end
          local activeData = displayData[currentIndex]
          if activeData and activeData.method and activeData.rate then
              Font.draw(activeData.method, 152 - Font.width(activeData.method), 112)
              Font.draw(activeData.rate, 152 - Font.width(activeData.rate), 128)
          end
        end
      else
        Font.draw(Strings("Empty Slot"), 8, 112)
      end
      love.graphics.setColor(1, 1, 1, 1)
      Font.__translucent_active = prev_translucent
    end)
    
    if not ok then
        print("DexNavGrid Draw Error: " .. tostring(err))
        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.setScissor()
    end
  end

  mod.content.screens:register("DEXNAV_GRID_VIEW", {
    new = function(game, encounterData, mapId) return DexNavGrid.new(game, encounterData, mapId) end
  })

  -- ---------------------------------------------------------------------
  -- PART 5: PERFECT KERNING TRUE-TYPE RENDER ENGINE & DETAIL PANEL
  -- ---------------------------------------------------------------------
  local function getModernFont(size, opts)
      local doubleSize = size * 2
      local isPixel = opts.pixelFont == true
      local key = tostring(doubleSize) .. (isPixel and "_pixel" or "_smooth")
      
      if not modernFonts[key] then
          local f
          if isPixel then
              pcall(function() f = love.graphics.newFont("assets/fonts/plainpixel/PlainPixel-Regular.ttf", doubleSize) end)
              if not f then pcall(function() f = love.graphics.newFont(doubleSize) end) end
              if f then f:setFilter("nearest", "nearest") end
          else
              pcall(function() f = love.graphics.newFont(doubleSize) end)
              if f then f:setFilter("linear", "linear") end
          end
          modernFonts[key] = f or love.graphics.getFont()
      end
      return modernFonts[key]
  end

  local function printScaled(text, x, y, fontObj, colorArray)
      love.graphics.setColor(colorArray[1], colorArray[2], colorArray[3], colorArray[4] or 1)
      love.graphics.setFont(fontObj)
      love.graphics.print(text, math.floor(x), math.floor(y), 0, 0.5, 0.5)
  end

  local function getScaledWidth(text, fontObj) return fontObj:getWidth(text) * 0.5 end
  local function getScaledHeight(fontObj) return fontObj:getHeight() * 0.5 end

  mod.hooks:wrap("render.hud", function(nextFn, ...)
      nextFn(...)
      
      if not activeDexNav then return end
      local game = activeDexNav.game
      if not game or not game.stack then return end
      if game.stack:top() ~= activeDexNav then return end

      local opts = game.save and game.save.options and game.save.options.modOptions and game.save.options.modOptions["gen1_modern_ui"] or {}
      local forceClassic = mod.options:get("modernUiStyle") == false
      local modernMod = mod.find and mod.find("gen1_modern_ui")
      if not modernMod or opts.menuUi == false or forceClassic or type(modernMod.exports) ~= "table" then return end

      local themeId = opts.theme or "gen1_modern_ui:classic_mono"
      local theme = modernMod.exports.themes[themeId] or modernMod.exports.themes["default"]
      if not theme then return end

      local w, h = love.graphics.getWidth(), love.graphics.getHeight()
      local sx, sy, sw, sh = 0, 0, w, h
      if love.window and love.window.getSafeArea then sx, sy, sw, sh = love.window.getSafeArea() end
      
      local uiScale = 1
      local fontScale = 1
      if modernMod.exports.getScaleTokens then
          local tokens = modernMod.exports.getScaleTokens({width = sw, height = sh})
          uiScale = tokens.uiScale or 1
          fontScale = tokens.fontScale or 1
      end
      
      local pOpac = (opts.panelOpacity or 100) / 100
      local fOpac = (opts.foregroundOpacity or 100) / 100
      
      local tC = theme.colors or {}
      local cSurface  = tC.surface or {0.05, 0.05, 0.05, 1}
      local cRaised   = tC.surfaceRaised or {0.15, 0.15, 0.15, 1}
      local cSelected = tC.selected or {0.2, 0.4, 0.8, 1}
      local cBackdrop = tC.backdrop or {0, 0, 0, 0.6}
      
      local function adapt(fg)
          if not fg then return fg end
          local bgLuma = 0.299 * (cSurface[1] or 0) + 0.587 * (cSurface[2] or 0) + 0.114 * (cSurface[3] or 0)
          local fgLuma = 0.299 * (fg[1] or 0) + 0.587 * (fg[2] or 0) + 0.114 * (fg[3] or 0)
          if math.abs(bgLuma - fgLuma) < 0.35 then
              if bgLuma > 0.5 then return {0.15, 0.15, 0.15, (fg[4] or 1) * fOpac}
              else return {0.95, 0.95, 0.95, (fg[4] or 1) * fOpac} end
          end
          return {fg[1], fg[2], fg[3], (fg[4] or 1) * fOpac}
      end

      local cText   = adapt(tC.text or {1, 1, 1, 1})
      local cMuted  = adapt(tC.textMuted or {0.6, 0.6, 0.6, 1})
      local cAccent = adapt(tC.accent or {0.4, 0.6, 1, 1})
      local cDivider = { (tC.divider or {0.5,0.5,0.5})[1], (tC.divider or {0.5,0.5,0.5})[2], (tC.divider or {0.5,0.5,0.5})[3], fOpac }

      local titleFont = getModernFont(math.floor((theme.typography and theme.typography.title or 24) * fontScale), opts)
      local bodyFont = getModernFont(math.floor((theme.typography and theme.typography.body or 17) * fontScale), opts)
      local captionFont = getModernFont(math.floor((theme.typography and theme.typography.caption or 13) * fontScale), opts)

      love.graphics.push("all")
      love.graphics.origin()

      local ok, err = pcall(function()
          love.graphics.setColor(cBackdrop[1], cBackdrop[2], cBackdrop[3], cBackdrop[4] or 1)
          love.graphics.rectangle("fill", 0, 0, w, h)

          local panelW = math.min(sw - 36 * uiScale, 780 * uiScale)
          local panelH = math.min(sh - 36 * uiScale, 620 * uiScale)
          local px = sx + (sw - panelW) / 2
          local py = sy + (sh - panelH) / 2
          local rad = (theme.radii and theme.radii.lg or 22) * uiScale

          love.graphics.setColor(cSurface[1], cSurface[2], cSurface[3], (cSurface[4] or 1) * pOpac)
          love.graphics.rectangle("fill", px, py, panelW, panelH, rad)

          love.graphics.setColor(cAccent[1], cAccent[2], cAccent[3], cAccent[4])
          love.graphics.rectangle("fill", px, py, panelW, 4 * uiScale, rad)
          love.graphics.rectangle("fill", px, py + 4 * uiScale, panelW, 2 * uiScale)

          local mapName = (activeDexNav.mapId or "UNKNOWN"):gsub("_", " ") .. " DEXNAV"
          while string.len(mapName) > 0 and getScaledWidth(mapName, titleFont) > panelW - 36 * uiScale do mapName = string.sub(mapName, 1, -2) end
          printScaled(mapName, px + 18 * uiScale, py + 18 * uiScale, titleFont, cText)

          local headerH = getScaledHeight(titleFont) + 36 * uiScale
          local footerH = getScaledHeight(captionFont) + 26 * uiScale
          local pad = 18 * uiScale
          
          local detailW = math.min(380 * uiScale, panelW * 0.48)
          local gridAvailW = panelW - pad * 3 - detailW
          local gridAvailH = panelH - headerH - footerH - pad
          
          local cols, gridRows = 5, 4
          local cellSize = math.max(1, math.min(gridAvailW / cols, gridAvailH / gridRows))
          local gridW, gridH = cellSize * cols, cellSize * gridRows
          local gx = px + pad
          local gy = py + headerH + (gridAvailH - gridH) / 2
          local cellRad = (theme.radii and theme.radii.sm or 8) * uiScale

          local dex = game.save.pokedex or {}
          local dexSeen = dex.seen or {}
          local dexOwned = dex.owned or {}

          for i = 1, 20 do
              local c, r = (i - 1) % cols, math.floor((i - 1) / cols)
              local cx, cy = gx + c * cellSize, gy + r * cellSize
              local mon = activeDexNav.boxData[i]

              if i == activeDexNav.index then
                  love.graphics.setColor(cSelected[1], cSelected[2], cSelected[3], (cSelected[4] or 1) * pOpac)
              else
                  love.graphics.setColor(cRaised[1], cRaised[2], cRaised[3], (cRaised[4] or 1) * pOpac)
              end
              
              love.graphics.rectangle("fill", cx + 2 * uiScale, cy + 2 * uiScale, cellSize - 4 * uiScale, cellSize - 4 * uiScale, cellRad)

              if mon then
                  local def = game.data.pokemon[mon.species] or {}
                  local dexNum = def.dex
                  local isSeen = dexSeen[mon.species] or (dexNum and (dexSeen[dexNum] or dexSeen[tostring(dexNum)]))
                  
                  local maxArtSize = cellSize * 0.68
                  local scale = math.min(maxArtSize / 16, maxArtSize / 16)
                  local qx = cx + (cellSize - 16 * scale) / 2
                  local qy = cy + (cellSize - 16 * scale) / 2
                  
                  drawBoxIconScaled(game, mon, qx, qy, i == activeDexNav.index, activeDexNav.blink, isSeen, scale, pOpac)
              end
          end

          -- ==========================================================
          -- THE ENHANCED DETAIL PANEL
          -- ==========================================================
          local dx = gx + gridW + pad
          local dy = py + headerH
          local dh = panelH - headerH - footerH - pad
          
          love.graphics.setColor(cRaised[1], cRaised[2], cRaised[3], (cRaised[4] or 1) * pOpac)
          love.graphics.rectangle("fill", dx, dy, detailW, dh, cellRad)
          
          local hoveredMon = activeDexNav.boxData[activeDexNav.index]
          if hoveredMon then
              local def = game.data.pokemon[hoveredMon.species] or {}
              local dexNum = def.dex
              local isSeen = dexSeen[hoveredMon.species] or (dexNum and (dexSeen[dexNum] or dexSeen[tostring(dexNum)]))
              local isOwned = hoveredMon.owned or hoveredMon.caught or dexOwned[hoveredMon.species] or (dexNum and (dexOwned[dexNum] or dexOwned[tostring(dexNum)]))
              local name = isSeen and (def.name or hoveredMon.species) or "?????"

              local spriteImg, isTrueColor = getLargeSprite(game, hoveredMon.species)
              local spriteSize = 110 * uiScale
              local iy = dy + pad

              if spriteImg then
                  local okMap, sMap = pcall(require, "mods.crystal_animated_sprites_with_shiny_visuals.species_map")
                  local okData, aData = pcall(require, "mods.crystal_animated_sprites_with_shiny_visuals.animation_data")
                  
                  if okMap and okData and sMap and aData then
                      local dexAnim = sMap[hoveredMon.species]
                      if dexAnim then
                          local isShiny = false
                          if hoveredMon.dvs then
                              local okStats, Stats = pcall(require, "src.pokemon.Stats")
                              if okStats and Stats and Stats.isShiny then isShiny = Stats.isShiny(hoveredMon.dvs) end
                          end
                          
                          local variant = isShiny and "shiny" or "normal"
                          local durations = aData[variant] and aData[variant][tostring(dexAnim)]
                          
                          if durations and #durations > 0 then
                              local totalDuration = 0
                              for _, d in ipairs(durations) do totalDuration = totalDuration + (d > 0 and d or 100) end
                              
                              if totalDuration > 0 then
                                  local elapsed = (love.timer.getTime() * 1000) % totalDuration
                                  local currentFrame = 1
                                  local accum = 0
                                  for i, d in ipairs(durations) do
                                      accum = accum + (d > 0 and d or 100)
                                      if elapsed <= accum then
                                          currentFrame = i
                                          break
                                      end
                                  end
                                  
                                  local framePath = string.format("mods/crystal_animated_sprites_with_shiny_visuals/assets/front/%s/%d/%03d.png", variant, dexAnim, currentFrame)
                                  local okImg, img = pcall(love.graphics.newImage, framePath)
                                  if okImg and img then
                                      img:setFilter("nearest", "nearest")
                                      spriteImg = img
                                      isTrueColor = true
                                  end
                              end
                          end
                      end
                  end
                  
                  local iw, ih = spriteImg:getWidth(), spriteImg:getHeight()
                  local scale = math.min(spriteSize / iw, spriteSize / ih)
                  
                  local prevShader = love.graphics.getShader()
                  local appliedShader = false
                  
                  if isSeen then 
                      love.graphics.setColor(1, 1, 1, 1)
                      if not isTrueColor then
                          local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
                          if okFX and PaletteFX and PaletteFX.monPal then
                              local pal = PaletteFX.monPal(game.data, hoveredMon.species)
                              if not pal and game.data.palettes then
                                  pal = game.data.palettes["CRYSTAL_251_" .. hoveredMon.species]
                              end
                              if pal then
                                  local shader = PaletteFX.shader()
                                  if shader then
                                      pcall(PaletteFX.sendColors, shader, pal)
                                      love.graphics.setShader(shader)
                                      appliedShader = true
                                  end
                              end
                          end
                      end
                  else 
                      love.graphics.setShader()
                      love.graphics.setColor(0, 0, 0, 0.7) 
                  end

                  local qx = dx + (detailW - iw * scale) / 2
                  local qy = iy + (spriteSize - ih * scale) / 2
                  
                  love.graphics.draw(spriteImg, qx, qy, 0, scale, scale)
                  
                  if appliedShader then love.graphics.setShader(prevShader) end
              end

              local nameY = iy + spriteSize + pad * 0.5
              local nameW = getScaledWidth(name, titleFont)
              
              local bImg = nil
              local icons = game.data.icons or {}
              local iconDefs = icons.icons or {}
              local ballEntry = iconDefs["BALL"] or iconDefs["ball"]
              local ballPath = type(ballEntry) == "table" and (ballEntry.image or ballEntry.asset or ballEntry.path) or ballEntry
              
              if ballPath and type(ballPath) == "string" then
                  local bKey = ballPath .. "#raw"
                  if iconCache[bKey] == nil then
                      local okIcon, lImg = pcall(love.graphics.newImage, Assets.resolve(ballPath))
                      iconCache[bKey] = okIcon and lImg or false
                  end
                  bImg = iconCache[bKey]
              end

              local bSize = getScaledHeight(titleFont) * 0.8
              local bScale = bImg and (bSize / bImg:getHeight()) or 1
              local bWidth = bImg and (bImg:getWidth() * bScale + 8 * uiScale) or 0
              
              local totalW = bWidth + nameW
              local startX = dx + (detailW - totalW) / 2

              if bImg and isSeen then
                  if isOwned then 
                      love.graphics.setColor(1, 1, 1, 1)
                      local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
                      if okFX and PaletteFX and PaletteFX.monPal then
                          local pal = PaletteFX.monPal(game.data, "VOLTORB")
                          local shader = PaletteFX.shader()
                          if shader and pal then
                              pcall(PaletteFX.sendColors, shader, pal)
                              love.graphics.setShader(shader)
                          end
                      end
                  else 
                      love.graphics.setShader()
                      love.graphics.setColor(0.1, 0.1, 0.1, 0.9) 
                  end
                  
                  local ballX = startX
                  local ballY = nameY + (getScaledHeight(titleFont) - bSize)/2
                  
                  love.graphics.draw(bImg, ballX, ballY, 0, bScale, bScale)
                  love.graphics.setShader()
              end

              printScaled(name, startX + bWidth, nameY, titleFont, cText)

              local lvlY = nameY + getScaledHeight(titleFont) + 6 * uiScale
              local lvlText = ""
              if isSeen then
                  if hoveredMon.minLevel == hoveredMon.maxLevel then lvlText = "Lv " .. hoveredMon.minLevel
                  else lvlText = "Lv " .. hoveredMon.minLevel .. " - " .. hoveredMon.maxLevel end
              else lvlText = "Lv ?? - ??" end
              
              printScaled(lvlText, dx + (detailW - getScaledWidth(lvlText, bodyFont))/2, lvlY, bodyFont, cMuted)

              local colY = lvlY + getScaledHeight(bodyFont) + pad
              local leftX = dx + pad
              local rightX = dx + detailW * 0.56 
              
              printScaled("ENCOUNTER", leftX, colY, captionFont, cMuted)
              printScaled("KNOWN MOVES", rightX, colY, captionFont, cMuted)
              
              love.graphics.setColor(cDivider[1], cDivider[2], cDivider[3], cDivider[4])
              love.graphics.rectangle("fill", dx + pad, colY + getScaledHeight(captionFont) + 2 * uiScale, detailW - pad * 2, 1 * uiScale)

              local listY = colY + getScaledHeight(captionFont) + 8 * uiScale

              if isSeen then
                  local m = hoveredMon.methods or {}
                  local displayData = {}
                  local function formatRate(r)
                      local val = math.floor((tonumber(r) or 0) + 0.5)
                      if val > 100 then val = 100 end 
                      if val == 0 and (tonumber(r) or 0) > 0 then return "<1%" end
                      return val .. "%"
                  end

                  if m["GRASS"] then table.insert(displayData, { m = "Grass", r = formatRate(m["GRASS"]) }) end
                  if m["SURF"]  then table.insert(displayData, { m = "Surf", r = formatRate(m["SURF"]) }) end
                  if m["OLD"]   then table.insert(displayData, { m = "Old Rod", r = formatRate(m["OLD"]) }) end
                  if m["GOOD"]  then table.insert(displayData, { m = "Good Rod", r = formatRate(m["GOOD"]) }) end
                  if m["SUPER"] then table.insert(displayData, { m = "Super Rod", r = formatRate(m["SUPER"]) }) end

                  if #displayData > 0 then
                     for idx, activeData in ipairs(displayData) do
                         local rowY = listY + (idx - 1) * (getScaledHeight(bodyFont) + 6 * uiScale)
                         if activeData and activeData.m and activeData.r then
                             printScaled(activeData.m, leftX, rowY, bodyFont, cText)
                             local rateX = leftX + getScaledWidth(activeData.m, bodyFont) + 8 * uiScale
                             printScaled(activeData.r, rateX, rowY, bodyFont, cAccent)
                         end
                     end
                  else
                      printScaled("None", leftX, listY, bodyFont, cMuted)
                  end

                  local knownMoves = {}
                  local maxLvl = hoveredMon.maxLevel or 5
                  
                  local okPkmn, Pokemon = pcall(require, "src.pokemon.Pokemon")
                  local generatedNative = false
                  if okPkmn and Pokemon and type(Pokemon.new) == "function" then
                      local dummyOk, dummyMon = pcall(Pokemon.new, game.data, hoveredMon.species, maxLvl)
                      if dummyOk and dummyMon and type(dummyMon.moves) == "table" then
                          for _, mObj in ipairs(dummyMon.moves) do
                              local mId = type(mObj) == "table" and mObj.id or mObj
                              if mId then table.insert(knownMoves, mId) end
                          end
                          generatedNative = true
                      end
                  end
                  
                  if not generatedNative then
                      for _, mList in ipairs({def.moves, def.baseMoves, def.startMoves}) do
                          for _, mData in ipairs(mList or {}) do
                              if type(mData) == "string" then table.insert(knownMoves, mData)
                              elseif type(mData) == "table" and (mData.id or mData.move) then table.insert(knownMoves, mData.id or mData.move) end
                          end
                      end
                      for _, mList in ipairs({def.levelMoves, def.learnset}) do
                          for _, mData in ipairs(mList or {}) do
                              if type(mData) == "table" then
                                  local lvl = tonumber(mData.level) or tonumber(mData[1]) or 1
                                  local mId = mData.id or mData.move or mData[2]
                                  if mId and type(mId) == "string" and lvl <= maxLvl then table.insert(knownMoves, mId) end
                              end
                          end
                      end
                  end
                  
                  local uniqueMoves, seenMoves = {}, {}
                  for _, moveId in ipairs(knownMoves) do
                      if not seenMoves[moveId] then
                          table.insert(uniqueMoves, moveId)
                          seenMoves[moveId] = true
                      end
                  end
                  
                  local finalMoves = {}
                  for i = math.max(1, #uniqueMoves - 3), #uniqueMoves do table.insert(finalMoves, uniqueMoves[i]) end
                  
                  if #finalMoves == 0 then
                      printScaled("None", rightX, listY, bodyFont, cMuted)
                  else
                      for idx, moveId in ipairs(finalMoves) do
                          local rowY = listY + (idx - 1) * (getScaledHeight(bodyFont) + 6 * uiScale)
                          local moveDef = game.data.moves and game.data.moves[moveId]
                          local mName = moveDef and moveDef.name or moveId
                          mName = mName:gsub("_", " "):upper()
                          printScaled(mName, rightX, rowY, bodyFont, cText)
                      end
                  end
              else
                  printScaled("???", leftX, listY, bodyFont, cMuted)
                  printScaled("???", rightX, listY, bodyFont, cMuted)
              end
          else
              printScaled("Empty Slot", dx + (detailW - getScaledWidth("Empty Slot", bodyFont))/2, dy + dh/2 - getScaledHeight(bodyFont)/2, bodyFont, cMuted)
          end

          love.graphics.setColor(cDivider[1], cDivider[2], cDivider[3], cDivider[4])
          love.graphics.rectangle("fill", px + pad, py + panelH - footerH - 4 * uiScale, panelW - pad * 2, 1 * uiScale)

          printScaled("A: Select   B: Close", px + pad, py + panelH - footerH + 4 * uiScale, captionFont, cMuted)

          if activeDexNav.subMenuOpen then
              love.graphics.setColor(0, 0, 0, 0.4)
              love.graphics.rectangle("fill", px, py, panelW, panelH, rad)

              local menuW = 200 * uiScale
              local menuH = 180 * uiScale
              local mx = px + (panelW - menuW) / 2
              local my = py + (panelH - menuH) / 2
              
              love.graphics.setColor(cRaised[1], cRaised[2], cRaised[3], (cRaised[4] or 1) * pOpac)
              love.graphics.rectangle("fill", mx, my, menuW, menuH, theme.radii.md * uiScale)
              
              love.graphics.setColor(cAccent[1], cAccent[2], cAccent[3], cAccent[4])
              love.graphics.rectangle("fill", mx, my, menuW, 4 * uiScale, theme.radii.md * uiScale)
              
              local options = {"SEARCH", "REGISTER", "DEX", "CANCEL"}
              for i, opt in ipairs(options) do
                  local optY = my + 16 * uiScale + (i-1) * 36 * uiScale
                  if i == activeDexNav.subMenuIndex then
                      love.graphics.setColor(cSelected[1], cSelected[2], cSelected[3], (cSelected[4] or 1) * pOpac)
                      love.graphics.rectangle("fill", mx + 8 * uiScale, optY, menuW - 16 * uiScale, 32 * uiScale, theme.radii.sm * uiScale)
                      printScaled(opt, mx + 24 * uiScale, optY + 6 * uiScale, bodyFont, cText)
                  else
                      printScaled(opt, mx + 24 * uiScale, optY + 6 * uiScale, bodyFont, cMuted)
                  end
              end
          end
      end)
      
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.pop()
      
      if not ok then print("DexNav Modern Draw Error: " .. tostring(err)) end
  end)

  -- ---------------------------------------------------------------------
  -- PART 6: Overworld Integration
  -- ---------------------------------------------------------------------
  mod.hooks:wrap("ui.start_menu.items", function(nextFn, game, items)
    local out = nextFn(game, items)
    if type(out) ~= "table" then return out end
    return mod.ui.insertBefore(out, "SAVE", {
      label = "DEXNAV",
      onSelect = function()
        local encs, mapId = getMapEncounters(game)
        if #encs == 0 then
          require("src.core.Sound").play(game.data, "Denied")
          game.stack:push(TextBox.new(game, Strings("There are no wild\nPOKéMON here!\f")))
        else
          require("src.core.Sound").play(game.data, "Press_AB")
          mod.ui.push(game, "DEXNAV_GRID_VIEW", encs, mapId)
        end
      end,
    })
  end)

  local okOW, OverworldController = pcall(require, "src.world.OverworldController")
  if okOW and OverworldController then
    local handlers = rawget(OverworldController, "__qolSelectHandlers")
    if not handlers then
      handlers = {}
      local origHandle = OverworldController.handleInput
      OverworldController.handleInput = function(self, ...)
        for _, handler in pairs(OverworldController.__qolSelectHandlers) do
          if handler(self) then return end
        end
        return origHandle(self, ...)
      end
      OverworldController.__qolSelectHandlers = handlers
    end
    
    handlers["dexnav_select"] = function(ow)
      local Game = require("src.core.Game")
      if Game.input:wasPressed("select") and Game.save.dexNavReg then
        if not Game._dexNavTargetId and Game.stack:top() == ow then
          local reg = Game.save.dexNavReg
          local encs = getMapEncounters(Game)
          local isValid = false
          for _, enc in ipairs(encs) do
            if enc.species == reg.species then isValid = true break end
          end
          if isValid then spawnDexNavEncounter(Game, reg.species, reg.level)
          else
            require("src.core.Sound").play(Game.data, "Denied")
            Game.stack:push(TextBox.new(Game, Strings("This POKéMON isn't\nin this area!\f")))
          end
          return true 
        end
      end
      return false
    end

    if not OverworldController.__orig_update_dexnav then OverworldController.__orig_update_dexnav = OverworldController.update end
    OverworldController.update = function(self, dt)
      OverworldController.__orig_update_dexnav(self, dt)
      local Game = require("src.core.Game")
      if Game._dexNavTargetMapId and Game._dexNavTargetMapId ~= self.map.id then
         pcall(function() safeDespawnDexNavTarget(Game) end)
         return
      end
      local targetId = Game._dexNavTargetId
      if targetId then
        local targetNpc
        for _, n in ipairs(self.npcs) do
          -- Robust Check: Match ID or the Definition Owner
          if (n.id == targetId) or (n.def and n.def.runtime and n.def.owner == "DexNav") then 
            targetNpc = n
            break 
          end
        end
        if not targetNpc then pcall(function() safeDespawnDexNavTarget(Game) end); return end

        local species = targetNpc.def and targetNpc.def.dexNavSpecies or targetNpc.dexNavSpecies
        local hasW = targetNpc.def and targetNpc.def.dexNavHasWater or targetNpc.dexNavHasWater
        local hasG = targetNpc.def and targetNpc.def.dexNavHasGrass or targetNpc.dexNavHasGrass

        if self.player.bumpFrames and self.player.bumpFrames > 0 then
          local tx, ty = Collision.target(self.player.cellX, self.player.cellY, self.player.facing)
          local npc = self:npcAtCell(tx, ty)
          if npc and ((npc.id == targetId) or (npc.def and npc.def.runtime and npc.def.owner == "DexNav")) then
            self.player.bumpFrames = nil 
            if Game.stack:top() == self and not npc.frozen and not self.engaging and not (self.runner and self.runner:isRunning()) and not self.transitioning then
              startDexNavBattle(Game, self, npc)
            end
          end
        end

        if not targetNpc.moving and not targetNpc.frozen and not self.transitioning then
          targetNpc.dexNavTimer = (targetNpc.dexNavTimer or 0) + 1
          if targetNpc.dexNavTimer > 80 then
            targetNpc.dexNavTimer = 0
            local dirs = {"up", "down", "left", "right"}
            local d = dirs[math.random(4)]
            local nx, ny = Collision.target(targetNpc.cellX, targetNpc.cellY, d)
            if isValidTile(Game, self.map, nx, ny, hasW, hasG) and (self.map:isWalkableCell(nx, ny) or self.map:isWaterCell(nx, ny)) and not Collision.occupied(self.entities, nx, ny, targetNpc) then
              if self.scriptMove then
                  self:scriptMove(targetNpc, d, 1)
              else
                  OverworldController:scriptMove(targetNpc, d, 1)
              end
            else
              if targetNpc.scriptFace then targetNpc:scriptFace(d) end
            end
          end
        end
      end
    end
    
    mod.events:on("world.interacted", function(event)
      local Game = require("src.core.Game")
      if event.kind == "npc" and event.target then
        local isDexNav = (event.target.id == Game._dexNavTargetId) or (event.target.def and event.target.def.runtime and event.target.def.owner == "DexNav")
        if isDexNav then
          local ow = Game.world or Game.overworld
          local isGen2 = Game.world ~= nil
          
          -- Gen 2's World is not on the state stack, so we adjust the check here
          local canInteract = false
          if isGen2 then
              canInteract = not ow.engaging and not (ow.runner and ow.runner:isRunning()) and not ow.transitioning
          else
              canInteract = (Game.stack:top() == ow) and not ow.engaging and not (ow.runner and ow.runner:isRunning()) and not ow.transitioning
          end
          
          if canInteract then
             startDexNavBattle(Game, ow, event.target)
          end
        end
      end
    end)

    mod.events:on("battle.ended", function(event)
        local Game = require("src.core.Game")
        if Game._dexNavTargetId then
            if Game.save.defeatedTrainers then Game.save.defeatedTrainers[Game._dexNavTargetId] = nil end
            if Game.save.itemsTaken then Game.save.itemsTaken[Game._dexNavTargetId] = nil end
            pcall(function() safeDespawnDexNavTarget(Game) end)
        end
    end)
  end
  mod.log:info("DexNav Grid UI Mod: Gen 2 Support Enabled!")
end
