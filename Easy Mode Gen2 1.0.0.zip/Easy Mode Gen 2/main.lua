return function(mod)

  local currentAttacker = nil
  local currentBattle = nil

  -- ==========================================
  -- UNIVERSAL ADAPTERS (Gen 1 vs Gen 2)
  -- ==========================================
  
  -- Gen 1 uses 'battler.mon', Gen 2 uses the raw 'battler' object
  local function getMon(battler)
    if not battler then return nil end
    return battler.mon or battler
  end

  -- Gen 2 doesn't always have .isPlayer flags, so we check the battle object directly
  local function isPlayer(battler, battle)
    if not battler then return false end
    if battler.id == "PLAYER" or battler.isPlayer then return true end
    if battle and battle.player == battler then return true end
    return false
  end

  -- Safely fetch the party array across both generations
  local function getParty(battle)
      if not battle then return nil end
      if battle.party then return battle.party end
      if battle.save and battle.save.party then return battle.save.party end
      if battle.game and battle.game.save and battle.game.save.party then return battle.game.save.party end
      return nil
  end

  -- ==========================================
  -- GOD MODE (Player Buffs)
  -- ==========================================
  local function applyGodMode(battler, battle)
    if isPlayer(battler, battle) then
      battler.reflect = true
      battler.lightScreen = true
      battler.mist = true
      battler.focusEnergy = true
      battler.curled = true -- <<< ADD THIS LINE: Permanent double damage for Rollout & Ice Ball
      battler.rageMove = { id = "RAGE", name = "RAGE" } 
      battler.rage = true -- Gen 1 Native Rage
      battler.safeguardTurns = 5
      battler.endure = true 
      battler.flinched = false

      local mon = getMon(battler)
      if mon then mon.status = nil end
      
      battler.sleepTurns = nil
      battler.toxicCounter = nil
      battler.confusedTurns = nil
      battler.leechSeeded = nil
      battler.crystalTrapTurns = nil
      battler.cantEscape = nil
      battler.cursed = nil
      battler.nightmare = nil
      battler.disabledTurns = nil
      battler.encoreTurns = nil
      battler.perishTurns = nil
      
      if battle and battle.screens and battle.screens.player then
          battle.screens.player["EFFECT_REFLECT"] = 5
          battle.screens.player["EFFECT_LIGHT_SCREEN"] = 5
          battle.screens.player["EFFECT_SAFEGUARD"] = 5
          battle.screens.player["EFFECT_MIST"] = 5
      end
      
      if battle and battle.volatile then
          local v = battle:volatile(battler)
          if v then
              v.confuseCount = nil
              v.toxicCounter = nil
              v.sleepTurns = nil
              v.leechSeed = nil  
              v.perish = nil     
              v.trapsTarget = nil
              v.wrapCount = nil
              v.destinyBond = nil
              v.disabledMove = nil
              v.encoreMove = nil
              v.rage = true 
              v.recharge = nil 
              v.cursed = nil -- <<< ADD THIS HERE: Clears the actual Curse volatile flag
          end
      end
    end
  end

  -- ==========================================
  -- DOOM MODE (Enemy Debuffs)
  -- ==========================================
  local function applyDoomMode(battler, battle)
    if not isPlayer(battler, battle) then
      battler.leechSeeded = true -- Restored Leech Seed property
      battler.protect = nil
      battler.endure = nil
      battler.destinyBond = nil
      battler.cantEscape = true
      battler.foresight = true -- Keeps Ghost types vulnerable
      
      if battle and battle.volatile then
          local v = battle:volatile(battler)
          if v then
             v.leechSeed = true -- Restored Leech Seed volatile flag
             v.wrapCount = 5 
             v.inLove = true    -- Forces the Attract debuff
             v.attracted = true -- Fallback for alternative volatile naming
          end
      end
    end
  end

  -- ==========================================
  -- UNIVERSAL BATTLE LOOP ADAPTER
  -- ==========================================
  local function applyToAllBattlers(battle, func)
    if not battle then return end
    if battle.sides then
      for _, side in ipairs(battle.sides) do
        for _, battler in ipairs(side.battlers) do 
          func(battler, battle)
        end
      end
    end
    -- Guarantees the lead Gen 2 battlers are explicitly targeted
    if battle.player then func(battle.player, battle) end
    if battle.enemy then func(battle.enemy, battle) end
  end

  mod.events:on("battle.started", function(ev)
    applyToAllBattlers(ev.battle, function(battler, battle)
      applyGodMode(battler, battle)
      applyDoomMode(battler, battle)
    end)
  end)

  mod.events:on("battle.battler_switched", function(ev)
    applyToAllBattlers(ev.battle, function(battler, battle)
      applyGodMode(battler, battle)
      applyDoomMode(battler, battle)
    end)
  end)

  mod.events:on("battle.turn_started", function(ev)
    local battle = ev.battle
    applyToAllBattlers(battle, function(battler, b)
      applyGodMode(battler, b)
      applyDoomMode(battler, b)
    end)
    
    if battle and battle.turnCount and battle.turnCount > 0 and battle.turnCount % 3 == 0 then
      applyToAllBattlers(battle, function(battler, b)
        local mon = getMon(battler)
        if not isPlayer(battler, b) and mon and mon.hp > 0 then
          local dmg = math.max(1, math.floor((mon.stats.hp or 1) / 3))
          mon.hp = math.max(1, mon.hp - dmg)
          if b.sayNext then 
            b:sayNext("The FUTURE SIGHT attack hit " .. (battler.name or "the enemy") .. "!") 
          end
        end
      end)
    end
  end)

  mod.events:on("battle.move_used", function(ev)
    currentAttacker = ev.user
    currentBattle = ev.battle
    if isPlayer(ev.user, ev.battle) then
      ev.user.comboHitCount = 0 
    end
    -- FIX: Force apply repeatedly during move execution to override Gen 2's volatile clears
    applyToAllBattlers(ev.battle, function(battler, b)
      applyGodMode(battler, b)
      applyDoomMode(battler, b)
    end)
  end)

  mod.events:on("battle.ended", function(ev)
    local party = getParty(ev.battle)
    local gameData = ev.game and ev.game.data or (ev.battle and ev.battle.data)
    if party and gameData then
      for _, mon in ipairs(party) do
        if mon.moves then
          for _, move in ipairs(mon.moves) do
            local mdef = gameData.moves[move.id]
            if mdef then
              local maxPP = math.floor(mdef.pp * 1.6)
              if maxPP > 61 then maxPP = 61 end
              move.ppups = 3
              move.pp = maxPP
              move.maxPp = maxPP -- Gen 2 requirement
            end
          end
        end
      end
      mod.log:info("Easy Mode: All Party PP Maxed and Restored!")
    end
  end)

  -- ==========================================
  -- ULTIMATE GOD MODE RNG (100% Crits, Accuracy & Effects)
  -- ==========================================
  
  -- Gen 1 RNG Hijack
  local ok1, BS1 = pcall(require, "src.battle.BattleState")
  if ok1 and BS1.executeAction then
    if not BS1._godModeRngHooked then
      BS1._godModeRngHooked = true
      local origExecute = BS1.executeAction
      BS1.executeAction = function(self, user, target, action)
        local origRng = self.rng
        if isPlayer(user, self) then
          self.rng = function(a, b)
            if a == 0 and b == 255 then return 0 end
            return origRng(a, b)
          end
        end
        local result = { origExecute(self, user, target, action) }
        self.rng = origRng
        return unpack(result)
      end
    end
  end

  -- Gen 2 RNG Hijack
  local ok2, BS2 = pcall(require, "src.battle.gen2.Battle")
  if ok2 and BS2.useMove then
    if not BS2._godModeRngHooked then
      BS2._godModeRngHooked = true
      local origUseMove = BS2.useMove
      BS2.useMove = function(self, user, target, moveId)
        local origRng = self.rng
        local origRandom = self.random
        if isPlayer(user, self) then
          local customRng = function(a, b)
            if a == 0 and b == 255 then return 0 end
            return origRng and origRng(a, b) or 0
          end
          self.rng = customRng
          self.random = function(n)
             if n == 256 or n == 255 or n == 100 then return 0 end
             return origRandom and origRandom(n) or 0
          end
        end
        local result = { origUseMove(self, user, target, moveId) }
        self.rng = origRng
        self.random = origRandom
        return unpack(result)
      end
    end
  end

  -- ==========================================
  -- GUARANTEED CRITICAL HITS
  -- ==========================================
  mod.hooks:wrap("battle.crit", function(origFn, ctx)
      -- If the player is attacking, bypass the math and guarantee a crit!
      if isPlayer(ctx.attacker, ctx.battle) then
          return true
      end
      
      -- Otherwise, let the enemy roll normally
      return origFn(ctx)
  end)
    
  -- ==========================================
  -- MODERN MOVE INTERACTIONS & IMMUNITIES
  -- ==========================================
  mod.hooks:wrap("battle.accuracy", function(nextFn, ctx)
    -- FIX: Force flags ON right before a move's accuracy is calculated
    applyToAllBattlers(ctx.battle, function(battler, b)
      applyGodMode(battler, b)
      applyDoomMode(battler, b)
    end)
  
    local move = ctx.move or (ctx.action and ctx.action.move)
    local target = ctx.defender or ctx.target
    local user = ctx.attacker or ctx.user
    local battle = ctx.battle
    
    if move then
      local id = move.id
      if id == "FISSURE" or id == "HORN_DRILL" or id == "GUILLOTINE" or id == "OHKO" then
        if isPlayer(target, battle) then return false end 
      end
      if id == "DREAM_EATER" and isPlayer(user, battle) then return true end
    end
    
    if target and target.invulnerable and move then
      local chargingId = nil
      if target.chargingMove then
          chargingId = target.chargingMove.id
      elseif battle and battle.volatile then
          local v = battle:volatile(target)
          if v then chargingId = v.chargeMove end
      end

      if move.id == "THUNDER" and chargingId == "FLY" then return true end
      if move.id == "EARTHQUAKE" and chargingId == "DIG" then return true end
    end

    if isPlayer(user, battle) then 
      if target and target.substituteHP then target.substituteHP = nil end
      return true 
    end

    if isPlayer(target, battle) and move then
      local blockedEffects = {
        SLEEP_EFFECT = true, POISON_EFFECT = true, PARALYZE_EFFECT = true,
        CONFUSION_EFFECT = true, LEECH_SEED_EFFECT = true, DISABLE_EFFECT = true,
        ATTACK_DOWN1_EFFECT = true, DEFENSE_DOWN1_EFFECT = true, SPEED_DOWN1_EFFECT = true,
        SPECIAL_DOWN1_EFFECT = true, ACCURACY_DOWN1_EFFECT = true, EVASION_DOWN1_EFFECT = true,
        DEFENSE_DOWN2_EFFECT = true,
        CRYSTAL_EFFECT_01 = true, CRYSTAL_EFFECT_21 = true, CRYSTAL_EFFECT_42 = true,
        CRYSTAL_EFFECT_06 = true, CRYSTAL_EFFECT_43 = true, CRYSTAL_EFFECT_31 = true,
        CRYSTAL_EFFECT_4C = true, CRYSTAL_EFFECT_54 = true, CRYSTAL_EFFECT_56 = true,
        CRYSTAL_EFFECT_1F = true, CRYSTAL_EFFECT_2A = true,
      }
      if blockedEffects[move.effect] then return false end
    end
    
    return nextFn(ctx)
  end)

  -- ==========================================
  -- CONSOLIDATED DAMAGE MATH & COMBOS
  -- ==========================================
   mod.hooks:wrap("battle.damage", function(nextFn, ctx)
    -- Force Rage flags ON milliseconds before taking damage!
    applyToAllBattlers(ctx.battle, function(battler, b)
      applyGodMode(battler, b)
      applyDoomMode(battler, b)
    end)
    
    local results = { nextFn(ctx) }
    local dmg = results[1]

    if type(dmg) == "number" then
      local move = ctx.move or (ctx.action and ctx.action.move)
      local target = ctx.defender or ctx.target
      local user = ctx.attacker or ctx.user
      local battle = ctx.battle
      
      -- ==========================================
      -- THE ZERO-DAMAGE IMMUNITY BYPASS
      -- ==========================================
      -- If the inner engine secretly zeroed out the damage due to an immunity, force it!
      if dmg == 0 and move and (move.power or 0) > 0 and isPlayer(user, battle) then
        local mon = getMon(user)
        local enemy = getMon(target)
        
        local level = mon and mon.level or 100
        local atk = mon and mon.stats and mon.stats.attack or 100
        local def = enemy and enemy.stats and enemy.stats.defense or 100
        
        -- Standard raw Pokémon damage formula (with a cheeky 1.5x STAB bonus)
        dmg = math.max(1, math.floor((((2 * level / 5 + 2) * move.power * atk / def) / 50) + 2) * 1.5)
        
        -- Fix the info block so the engine logs it as a neutral hit
        if results[2] then
           results[2].effectiveness = 10
           results[2].typeMult = 10
           results[2].immune = false
        end
      end
      -- ==========================================

      if move then
          -- ... (Keep the rest of your combo math exactly as it is below this point) ...
        if move.id == "PSYWAVE" then
          if isPlayer(user, battle) then dmg = math.floor((getMon(user).level or 100) * 1.5)
          elseif isPlayer(target, battle) then dmg = 1 end
        end

        if move.id == "COUNTER" or move.id == "MIRROR_COAT" then
          if isPlayer(user, battle) then
            local mon = getMon(user)
            local missingHP = (mon.stats.hp or 100) - (mon.hp or 100)
            dmg = math.max(1, missingHP * 2)
          end
        end

        if move.id == "REVERSAL" or move.id == "FLAIL" then
          if isPlayer(user, battle) then dmg = math.floor(dmg * 2) end
        end

        if move.type == "WATER" or move.type == "FIRE" then
          if isPlayer(user, battle) then dmg = math.floor(dmg * 1.5) 
          elseif isPlayer(target, battle) then dmg = math.floor(dmg * 0.5) end
        end
              
        if isPlayer(user, battle) then
          if move.id == "FURY_CUTTER" or move.id == "ROLLOUT" or move.id == "ICE_BALL" or move.id == "TRIPLE_KICK" then
            user.comboHitCount = (user.comboHitCount or 0) + 1
            local stages = math.min(user.comboHitCount - 1, 4)
            local multiplier = 2 ^ stages
            dmg = math.floor(dmg * multiplier)
          end
        end

        if move.id == "STOMP" and target and target.minimized then
          dmg = math.floor(dmg * 2)
        end
        
        local chargingId = nil
        if target and target.chargingMove then
            chargingId = target.chargingMove.id
        elseif battle and battle.volatile then
            local v = battle:volatile(target)
            if v then chargingId = v.chargeMove end
        end
        
        -- FIX: Now both Earthquake AND Magnitude 10 will deal double damage (300 Base Power!) to Digging targets!
        if (move.id == "EARTHQUAKE" or move.id == "MAGNITUDE") and chargingId == "DIG" then
          dmg = math.floor(dmg * 2)
        end
      end -- <<< ADD THIS MISSING 'END' HERE!

      if isPlayer(target, battle) then
        dmg = math.floor(dmg * 0.25)
        if dmg < 1 then dmg = 1 end
        
        local mon = getMon(target)
        if mon and mon.hp > 0 then
          if dmg >= mon.hp then
            dmg = mon.hp - 1
          end
        end
      end

      results[1] = dmg
    end

    return unpack(results)
  end)

  mod.events:on("battle.status_inflicted", function(ev)
    if isPlayer(ev.target, ev.battle) then
      local mon = getMon(ev.target)
      if mon then mon.status = nil end
    end
  end)

  -- ==========================================
  -- TOTAL STATUS IMMUNITY & AI MANIPULATION
  -- ==========================================
  local function hookCoreRoutines(modulePath)
    local ok, BattleClass = pcall(require, modulePath)
    if ok then
      
      -- 1. AI State Hijack: Inject the missing variables into the table you found!
      if BattleClass.smartAiState and not BattleClass._godModeAiHooked then
        BattleClass._godModeAiHooked = true
        local origSmartAi = BattleClass.smartAiState
        BattleClass.smartAiState = function(self)
          local st = origSmartAi(self)
          st.enemyInLove = true  -- AI knows it's infatuated
          st.playerInLove = true -- Tricks AI logic that relies on the reverse perspective
          return st
        end
      end

      -- 2. Mechanical Infatuation (Enemy) & Flinch Immunity (Player)
      if BattleClass.canAct and not BattleClass._godModeCanActHooked then
        BattleClass._godModeCanActHooked = true
        local origCanAct = BattleClass.canAct
        BattleClass.canAct = function(self, mon)
          if isPlayer(mon, self) then
            -- Player ignores flinch natively before the engine reads it
            local v = self:volatile(mon)
            if v and v.flinched then v.flinched = nil end
          else
            -- Enemy has a guaranteed 50% chance to lose its turn
            local roll = self.random and self.random(100) or math.random(0, 99)
            if roll < 50 then
              if self.emit then
                self:emit({ kind = "message", text = self:monName(mon) .. " is in love!" })
                self:emit({ kind = "message", text = self:monName(mon) .. " is immobilized by love!" })
              end
              return false
            end
          end
          return origCanAct(self, mon)
        end
      end

      -- 3. Total Immunity to Major Statuses (Poison, Burn, Sleep, Freeze, Paralyze)
      if BattleClass.applyStatus and not BattleClass._godModeStatusHooked then
        BattleClass._godModeStatusHooked = true
        local origApplyStatus = BattleClass.applyStatus
        BattleClass.applyStatus = function(self, mon, status, source)
          if isPlayer(mon, self) then return false end
          return origApplyStatus(self, mon, status, source)
        end
      end

      -- 4. Total Immunity to Confusion
      if BattleClass.applyConfusion and not BattleClass._godModeConfusionHooked then
        BattleClass._godModeConfusionHooked = true
        local origApplyConfusion = BattleClass.applyConfusion
        BattleClass.applyConfusion = function(self, mon, turns, source)
          if isPlayer(mon, self) then return false end
          return origApplyConfusion(self, mon, turns, source)
        end
      end
      
    end
  end

  hookCoreRoutines("src.battle.Battle")
  hookCoreRoutines("src.battle.gen2.Battle")
  
  -- ==========================================
  -- GOD MODE DREAM EATER (Works on awake targets)
  -- ==========================================
  local function hookDreamEater(modulePath, funcName)
    local ok, BattleClass = pcall(require, modulePath)
    if ok and BattleClass[funcName] then
      if not BattleClass._godModeDreamEaterHooked then
        BattleClass._godModeDreamEaterHooked = true
        local origUseMove = BattleClass[funcName]

        BattleClass[funcName] = function(self, user, target, arg4)
          local moveId = type(arg4) == "string" and arg4 or (arg4 and arg4.move and arg4.move.id)
          local moves = self.data and self.data.moves
          local moveDef = moves and moveId and moves[moveId]

          local origStatus = nil
          
          -- Trick the engine into thinking the target is asleep
          if isPlayer(user, self) and moveDef and moveDef.effect == "EFFECT_DREAM_EATER" then
            origStatus = target.status or "none"
            target.status = "sleep"
          end

          local result = { origUseMove(self, user, target, arg4) }

          -- Restore the original status immediately after the hit
          if origStatus then
            target.status = (origStatus == "none") and nil or origStatus
          end

          return unpack(result)
        end
      end
    end
  end

  hookDreamEater("src.battle.BattleState", "executeAction") -- Gen 1
  hookDreamEater("src.battle.gen2.Battle", "useMove")       -- Gen 2

  -- ==========================================
  -- BANNED ENEMY MOVES (Protect, Endure, Destiny Bond)
  -- ==========================================
  local function hookBannedEffects(modulePath)
    local ok, BattleClass = pcall(require, modulePath)
    if ok and BattleClass.MOVE_EFFECT_RECORDS then
      if not BattleClass._godModeBannedEffectsHooked then
        BattleClass._godModeBannedEffectsHooked = true
        
        local BANNED = { "EFFECT_PROTECT", "EFFECT_ENDURE", "EFFECT_DESTINY_BOND" }
        
        for _, effectName in ipairs(BANNED) do
          if BattleClass.MOVE_EFFECT_RECORDS[effectName] then
            local origRun = BattleClass.MOVE_EFFECT_RECORDS[effectName].run
            
            BattleClass.MOVE_EFFECT_RECORDS[effectName].run = function(self, attacker, defender, def, moveId, sureHit)
              -- If the enemy tries to use a banned stall move, fail it
              if not isPlayer(attacker, self) then
                self:markMissed()
                self:emit({ kind = "message", text = "But it failed!" })
                return
              end
              
              -- Player can use them normally
              return origRun(self, attacker, defender, def, moveId, sureHit)
            end
          end
        end
      end
    end
  end

  hookBannedEffects("src.battle.Battle")
  hookBannedEffects("src.battle.gen2.Battle")
  
  -- ==========================================
  -- INSTANT CHARGE MOVES (Fly, Dig, Solarbeam, etc.)
  -- ==========================================
  mod.hooks:wrap("battle.charge_required", function(origFn, ctx)
    -- If the player is the one attacking, return false to bypass the charge turn completely
    if isPlayer(ctx.user, ctx.battle) then
      return false
    end
    
    -- Otherwise, let the enemy charge normally
    return origFn(ctx)
  end)

local function hookRecoil(modulePath)
  local ok, Effects = pcall(require, modulePath)
  if ok and Effects.recoilDamage then
    if not Effects._godModeRecoilHooked then
      Effects._godModeRecoilHooked = true
      local origRecoil = Effects.recoilDamage
      Effects.recoilDamage = function(dealt)
        -- Bypass the math and return 0 recoil for the player
        if currentAttacker and isPlayer(currentAttacker, currentBattle) then 
            return 0 
        end
        return origRecoil(dealt)
      end
    end
  end
end

hookRecoil("src.battle.Effects")
hookRecoil("src.battle.gen2.Effects")

local function hookSelfDestruct(modulePath)
  local ok, BattleClass = pcall(require, modulePath)
  if ok and BattleClass.selfdestructUser then
    if not BattleClass._godModeExplosionHooked then
      BattleClass._godModeExplosionHooked = true
      local origSelfDestruct = BattleClass.selfdestructUser
      BattleClass.selfdestructUser = function(self, attacker)
        -- Player survives the explosion!
        if isPlayer(attacker, self) then return end
        origSelfDestruct(self, attacker)
      end
    end
  end
end

hookSelfDestruct("src.battle.Battle")
hookSelfDestruct("src.battle.gen2.Battle")

  -- ==========================================
  -- GOD MODE MULTI-HIT CONVERSIONS (Player Only)
  -- ==========================================
  local MULTI_HIT_MOVES = { 
    WRAP=true, BIND=true, FIRE_SPIN=true, CLAMP=true, WHIRLPOOL=true,
    THRASH=true, PETAL_DANCE=true, OUTRAGE=true, 
    ROLLOUT=true, ICE_BALL=true, FURY_CUTTER=true,
    DOUBLE_KICK=true, TWINEEDLE=true, BONEMERANG=true, TRIPLE_KICK=true
  }

  local function hookUseMove(modulePath, funcName)
    local ok, BattleClass = pcall(require, modulePath)
    if ok and BattleClass[funcName] then
      if not BattleClass._godModeMultiHitHooked then
        BattleClass._godModeMultiHitHooked = true
        local origUseMove = BattleClass[funcName]
        
        BattleClass[funcName] = function(self, user, target, arg4)
          -- Gen 1 passes the action object as arg4, Gen 2 passes the moveId string
          local moveId = type(arg4) == "string" and arg4 or (arg4 and arg4.move and arg4.move.id)
          local moves = self.data and self.data.moves
          local moveDef = moves and moveId and moves[moveId]
          
          local origEffect = nil
          
          -- If the player attacks, temporarily swap the effect in the database
          if isPlayer(user, self) and moveDef and MULTI_HIT_MOVES[moveId] then
            origEffect = moveDef.effect
            moveDef.effect = "TWO_TO_FIVE_ATTACKS_EFFECT"
          end
          
          local result = { origUseMove(self, user, target, arg4) }
          
          -- Safely restore the original effect so enemies use the normal version
          if origEffect then
            moveDef.effect = origEffect
          end
          
          return unpack(result)
        end
      end
    end
  end

  hookUseMove("src.battle.BattleState", "executeAction") -- Gen 1 hook
  hookUseMove("src.battle.gen2.Battle", "useMove")       -- Gen 2 hook

  -- ==========================================
  -- GUARANTEED 5-HIT MULTI-HITS
  -- ==========================================
  local function hookHitCount(modulePath)
    local ok, Effects = pcall(require, modulePath)
    if ok and Effects.hitCount then
      if not Effects._godModeHitCountHooked then
        Effects._godModeHitCountHooked = true
        local origHitCount = Effects.hitCount
        
        Effects.hitCount = function(effect, roller)
          -- If the player is attacking, bypass the roll and force 5 hits
          if currentAttacker and isPlayer(currentAttacker, currentBattle) then
            return 5
          end
          
          -- Enemy rolls normally
          return origHitCount(effect, roller)
        end
      end
    end
  end

  hookHitCount("src.battle.Effects")
  hookHitCount("src.battle.gen2.Effects")
  
  -- ==========================================
  -- CRYSTAL 251: MASTER OVERRIDES
  -- ==========================================
  local TypeChart
  pcall(function() TypeChart = package.loaded["src.battle.TypeChart"] or require("src.battle.TypeChart") end)
  if TypeChart and TypeChart.effectiveness then
    local origEff = TypeChart.effectiveness
    TypeChart.effectiveness = function(moveType, targetTypes)
      local mult = origEff(moveType, targetTypes)
      if currentAttacker and isPlayer(currentAttacker, currentBattle) then
        if mult == 0 then return 10 end
      end
      return mult
    end
  end

  local CrystalDamage
  pcall(function() CrystalDamage = package.loaded["mods.CRYSTAL_251.battle.crystal_damage"] or require("mods.CRYSTAL_251.battle.crystal_damage") end)
  if CrystalDamage and CrystalDamage.compute then
    local origCompute = CrystalDamage.compute
    CrystalDamage.compute = function(ctx, config)
      local target = ctx.target or ctx.defender
      if isPlayer(target, ctx.battle) then
         local mon = getMon(target)
         if mon and mon.hp <= 1 then
           if ctx.battle and ctx.battle.sayNext then
             ctx.battle:sayNext("It doesn't affect " .. (target.name or "the target") .. "!")
           end
           return 0, { crit=false, typeMult=0, immune=true, crystal251=true }
         end
      end
      return origCompute(ctx, config)
    end
  end

  local MultiTurn
  pcall(function() MultiTurn = package.loaded["mods.CRYSTAL_251.battle.multi_turn"] or require("mods.CRYSTAL_251.battle.multi_turn") end)
  if MultiTurn then
    if MultiTurn.twoToFiveCount then
      local origTwoToFive = MultiTurn.twoToFiveCount
      MultiTurn.twoToFiveCount = function(rng)
        if currentAttacker and isPlayer(currentAttacker, currentBattle) then return 5 end 
        return origTwoToFive(rng)
      end
    end

    if MultiTurn.perform then
      local origPerform = MultiTurn.perform
      MultiTurn.perform = function(ctx)
        local user = ctx.user or ctx.attacker
        if not isPlayer(user, ctx.battle) then
          user.rolloutCount = nil
          user.forcedMove = nil
          user.forcedMoveTurns = nil
          user.thrashTurns = nil
          user.furyCutterCount = nil
          user.crystalRageCounter = nil
        end
        return origPerform(ctx)
      end
    end
  end

  local SpecialDamage
  pcall(function() SpecialDamage = package.loaded["mods.CRYSTAL_251.battle.special_damage"] or require("mods.CRYSTAL_251.battle.special_damage") end)
  if SpecialDamage then
     if SpecialDamage.perform then
       local origPerform = SpecialDamage.perform
       SpecialDamage.perform = function(ctx)
         local target = ctx.target or ctx.defender
         local user = ctx.user or ctx.attacker
         
         if isPlayer(target, ctx.battle) then
            local mon = getMon(target)
            if mon and mon.hp <= 1 then
               local state = { ctx=ctx, failed=true, stop=true }
               if ctx.battle and ctx.battle.sayNext then ctx.battle:sayNext("It doesn't affect " .. (target.name or "the target") .. "!") end
               return state
            end
         end
         
         if ctx.move.id == "BEAT_UP" and isPlayer(user, ctx.battle) then
            local party = getParty(ctx.battle)
            if party then
                local phantomParty = {}
                local mon = getMon(user)
                for i = 1, 6 do
                    table.insert(phantomParty, { 
                        species = mon.species, 
                        level = mon.level, 
                        hp = 100, 
                        status = nil 
                    })
                end
                
                -- Temporary inject the phantom party into the battle state
                local origParty
                if ctx.battle.party then
                    origParty = ctx.battle.party
                    ctx.battle.party = phantomParty
                elseif ctx.battle.save and ctx.battle.save.party then
                    origParty = ctx.battle.save.party
                    ctx.battle.save.party = phantomParty
                elseif ctx.battle.game and ctx.battle.game.save and ctx.battle.game.save.party then
                    origParty = ctx.battle.game.save.party
                    ctx.battle.game.save.party = phantomParty
                end
                
                local state = origPerform(ctx)
                
                -- Restore the real party
                if ctx.battle.party then
                    ctx.battle.party = origParty
                elseif ctx.battle.save and ctx.battle.save.party then
                    ctx.battle.save.party = origParty
                elseif ctx.battle.game and ctx.battle.game.save and ctx.battle.game.save.party then
                    ctx.battle.game.save.party = origParty
                end
                
                return state
            end
         end
         return origPerform(ctx)
       end
     end
     
     if SpecialDamage.psywaveDamage then
       SpecialDamage.psywaveDamage = function(level, rng)
         if currentAttacker and isPlayer(currentAttacker, currentBattle) then 
            return math.floor((level or 100) * 1.5) 
         end
         return 1
       end
     end

     if SpecialDamage.reversalPower then
       local origRev = SpecialDamage.reversalPower
       SpecialDamage.reversalPower = function(hp, maxHP)
         if currentAttacker and isPlayer(currentAttacker, currentBattle) then return 200 end
         return origRev(hp, maxHP)
       end
     end

     if SpecialDamage.counterDamage then
       local origCounter = SpecialDamage.counterDamage
       SpecialDamage.counterDamage = function(last, wantedCategory, moveId, target)
         if currentAttacker and isPlayer(currentAttacker, currentBattle) then
            local mon = getMon(currentAttacker)
            local missingHP = (mon.stats.hp or 100) - (mon.hp or 100)
            return math.max(1, missingHP * 2)
         end
         return origCounter(last, wantedCategory, moveId, target)
       end
     end
  end

  local Actions
  pcall(function() Actions = package.loaded["mods.CRYSTAL_251.battle.crystal_actions"] or require("mods.CRYSTAL_251.battle.crystal_actions") end)
  if Actions then
    if Actions.checkObedience then
      local originalCheckObedience = Actions.checkObedience
      Actions.checkObedience = function(battle, user, action)
        if isPlayer(user, battle) then return { obey = true } end
        return originalCheckObedience(battle, user, action)
      end
    end
    if Actions.trainerItemEligible then
      Actions.trainerItemEligible = function(battle, item) return false end
    end
    if Actions.consumePP then
      local originalConsumePP = Actions.consumePP
      Actions.consumePP = function(battle, user, moveInst, isCalled)
        if isPlayer(user, battle) then return true, false end
        return originalConsumePP(battle, user, moveInst, isCalled)
      end
    end
  end

  local CrystalItems
  pcall(function() CrystalItems = package.loaded["mods.CRYSTAL_251.battle.crystal_items"] or require("mods.CRYSTAL_251.battle.crystal_items") end)
  if CrystalItems then
    if CrystalItems.firstMover then
      local originalFirstMover = CrystalItems.firstMover
      CrystalItems.firstMover = function(nextFn, a, aMove, b, bMove, ctx)
        local aPri = aMove and aMove.priority or 0
        local bPri = bMove and bMove.priority or 0
        if aPri == bPri then
          if isPlayer(a, ctx.battle) then return true end
          if isPlayer(b, ctx.battle) then return false end
        end
        return originalFirstMover(nextFn, a, aMove, b, bMove, ctx)
      end
    end
    if CrystalItems.modifyBaseDamage then
      local originalModifyBaseDamage = CrystalItems.modifyBaseDamage
      CrystalItems.modifyBaseDamage = function(user, move, damage)
        local newDamage = originalModifyBaseDamage(user, move, damage)
        if isPlayer(user, currentBattle) then newDamage = math.floor(newDamage * 1.1) end
        return newDamage
      end
    end
    if CrystalItems.modifyDamageStats then
      local originalModifyStats = CrystalItems.modifyDamageStats
      CrystalItems.modifyDamageStats = function(user, target, category, attack, defense)
        local atk, def = originalModifyStats(user, target, category, attack, defense)
        if isPlayer(user, currentBattle) then atk = atk * 2 end
        if isPlayer(target, currentBattle) then
          local boosted = def + math.floor(def / 2)
          if boosted > 255 then
            atk = math.max(1, math.floor(atk / 2))
            def = math.floor(boosted / 2)
          else
            def = boosted
          end
        end
        while atk > 255 or def > 255 do
          atk = math.max(1, math.floor(atk / 4))
          def = math.max(1, math.floor(def / 4))
        end
        return atk, def
      end
    end
    if CrystalItems.withBrightPowder then
      local originalBrightPowder = CrystalItems.withBrightPowder
      CrystalItems.withBrightPowder = function(nextFn, ctx)
        local target = ctx and (ctx.target or ctx.defender)
        if isPlayer(target, ctx.battle) then
          local originalRNG = ctx.rng
          ctx.rng = function(a, b)
            local roll = originalRNG(a, b)
            if a == 0 and b == 255 then return math.min(255, roll + 20) end
            return roll
          end
          local ok, result = pcall(nextFn, ctx)
          ctx.rng = originalRNG 
          if not ok then error(result, 0) end
          return result
        end
        return originalBrightPowder(nextFn, ctx)
      end
    end
  end
  
  local CrystalStatus
  pcall(function() CrystalStatus = package.loaded["mods.CRYSTAL_251.battle.crystal_status"] or require("mods.CRYSTAL_251.battle.crystal_status") end)
  if CrystalStatus then
    if CrystalStatus.leechSeed then
      local origLeechSeed = CrystalStatus.leechSeed
      CrystalStatus.leechSeed = function(ctx)
        local result = origLeechSeed(ctx)
        local v = ctx.battle and ctx.battle.volatile and ctx.battle:volatile(ctx.target)
        if (v and v.leechSeed) or (ctx.target and ctx.target.leechSeeded) then
          ctx.target.leechSeedCounter = 1 
        end
        return result
      end
    end

    if CrystalStatus.actionResidual then
      local origResidual = CrystalStatus.actionResidual
      CrystalStatus.actionResidual = function(battler, opponent, battle)
        -- FIX: Force Leech Seed flags ON milliseconds before Turn 1 ends!
        applyToAllBattlers(battle, function(b_ler, b)
          applyGodMode(b_ler, b)
          applyDoomMode(b_ler, b)
        end)
      
        local v = battle and battle.volatile and battle:volatile(battler)
        local wasSeeded = (v and v.leechSeed) or battler.leechSeeded
        
        if wasSeeded then 
           if v then v.leechSeed = nil end
           battler.leechSeeded = nil 
        end

        local out = origResidual(battler, opponent, battle)
        
        if wasSeeded then 
           if v then v.leechSeed = true end
           battler.leechSeeded = true 
        end

        local bMon = getMon(battler)
        local oMon = getMon(opponent)
        if wasSeeded and bMon and bMon.hp > 0 and oMon and oMon.hp > 0 then
          battler.leechSeedCounter = battler.leechSeedCounter or 1
          local dmgCalc = math.max(1, math.floor(bMon.stats.hp / 16)) * battler.leechSeedCounter
          local damage = math.max(1, math.floor(dmgCalc))
          
          damage = math.min(damage, bMon.hp)
          bMon.hp = bMon.hp - damage
          oMon.hp = math.min(oMon.stats.hp, oMon.hp + damage)
          battler.leechSeedCounter = math.min(15, battler.leechSeedCounter + 1)

          local battlerName = isPlayer(battler, battle) and tostring(battler.name) or ("Enemy " .. tostring(battler.name))
          out[#out + 1] = "LEECH SEED\nsapped " .. battlerName .. "!"
        end
        return out
      end
    end
  end
  
  local CrystalSwitching
  pcall(function() CrystalSwitching = package.loaded["mods.CRYSTAL_251.battle.crystal_switching"] or require("mods.CRYSTAL_251.battle.crystal_switching") end)
  if CrystalSwitching and CrystalSwitching.forceSwitch then
    local origForceSwitch = CrystalSwitching.forceSwitch
    CrystalSwitching.forceSwitch = function(ctx)
      local target = ctx.target or ctx.defender
      if isPlayer(target, ctx.battle) then
        if ctx.battle and ctx.battle.cancelMoveAnim then
          ctx.battle:cancelMoveAnim()
        end
        local targetName = target.isPlayer and tostring(target.name) or ("Enemy " .. tostring(target.name))
        return { "It didn't affect " .. targetName .. "!" }
      end
      return origForceSwitch(ctx)
    end
  end

  -- ==========================================
  -- MAGNITUDE HACK (Always 10 for Player)
  -- ==========================================
  local function hookMagnitude(modulePath)
    local Effects
    pcall(function() Effects = package.loaded[modulePath] or require(modulePath) end)
    
    if Effects and Effects.magnitudePower then
      if not Effects._godModeMagnitudeHooked then
        Effects._godModeMagnitudeHooked = true
        local origMag = Effects.magnitudePower
        
        Effects.magnitudePower = function(rng)
          -- If the player uses Magnitude, bypass the dice and return Power 150, Magnitude 10
          if currentAttacker and isPlayer(currentAttacker, currentBattle) then
            return 150, 10
          end
          -- Otherwise, let the enemy roll normally
          return origMag(rng)
        end
      end
    end
  end

  -- Safely apply the hack to both Gen 1 and Gen 2 engines!
  hookMagnitude("src.battle.Effects")
  hookMagnitude("src.battle.gen2.Effects")
  
  -- ==========================================
  -- INSTANT BIDE (Missing HP * 2)
  -- ==========================================
  local function hookBide(modulePath)
    local ok, BattleClass = pcall(require, modulePath)
    if ok and BattleClass.MOVE_EFFECT_RECORDS and BattleClass.MOVE_EFFECT_RECORDS["EFFECT_BIDE"] then
      if not BattleClass._godModeBideHooked then
        BattleClass._godModeBideHooked = true
        local origBide = BattleClass.MOVE_EFFECT_RECORDS["EFFECT_BIDE"].run
        
        BattleClass.MOVE_EFFECT_RECORDS["EFFECT_BIDE"].run = function(self, attacker, defender, def, moveId, sureHit)
          -- If the player uses Bide, make it instant and base it on missing HP
          if isPlayer(attacker, self) then
            local mon = getMon(attacker)
            local maxHp = mon.maxHp or (mon.stats and mon.stats.hp) or 100
            local missingHP = maxHp - (mon.hp or maxHp)
            local damage = math.max(1, missingHP * 2)
            
            self:emit({ kind = "message", text = self:monName(attacker) .. " unleashed energy!" })
            self:dealDamage(attacker, defender, damage, { move = def, moveId = moveId })
            return
          end
          
          -- Enemy uses normal Bide logic
          return origBide(self, attacker, defender, def, moveId, sureHit)
        end
      end
    end
  end

  hookBide("src.battle.Battle")
  hookBide("src.battle.gen2.Battle")
  
  -- ==========================================
  -- BYPASS ALL TYPE IMMUNITIES (God Mode)
  -- ==========================================
  local function hookImmunities(modulePath)
    local ok, Damage = pcall(require, modulePath)
    if ok and Damage.typeMultiplier then
      if not Damage._godModeTypeHooked then
        Damage._godModeTypeHooked = true
        local origMult = Damage.typeMultiplier
        
        Damage.typeMultiplier = function(moveType, targetTypes, matchups)
          local mult = origMult(moveType, targetTypes, matchups)
          
          -- If the player attacks, convert any immunity (0x) to neutral damage (1x)
          if currentAttacker and isPlayer(currentAttacker, currentBattle) then
            if mult == 0 then 
              return 10 
            end
          end
          
          return mult
        end
      end
    end
  end

  hookImmunities("src.battle.gen2.Damage")
  hookImmunities("src.battle.Damage") -- Gen 1 fallback

  -- ==========================================
  -- IMMUNITY TO CURSE
  -- ==========================================
  local function hookCurse(modulePath)
    local ok, BattleClass = pcall(require, modulePath)
    if ok and BattleClass.MOVE_EFFECT_RECORDS and BattleClass.MOVE_EFFECT_RECORDS["EFFECT_CURSE"] then
      if not BattleClass._godModeCurseHooked then
        BattleClass._godModeCurseHooked = true
        local origCurse = BattleClass.MOVE_EFFECT_RECORDS["EFFECT_CURSE"].run
        
        BattleClass.MOVE_EFFECT_RECORDS["EFFECT_CURSE"].run = function(self, attacker, defender, def, moveId, sureHit)
          -- If the enemy tries to curse the player, make it fail instantly
          if isPlayer(defender, self) then
            self:markMissed()
            self:emit({ kind = "message", text = "It doesn't affect " .. self:monName(defender) .. "!" })
            return
          end
          
          -- Otherwise, proceed with normal Curse logic
          return origCurse(self, attacker, defender, def, moveId, sureHit)
        end
      end
    end
  end

  hookCurse("src.battle.Battle")
  hookCurse("src.battle.gen2.Battle")
  
  mod.log:info("Easy Mode: Master Script loaded successfully!")
end
