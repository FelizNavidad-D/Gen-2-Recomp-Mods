return function(mod)
  if mod.hooks and mod.hooks.wrap then
    
    -- ==========================================
    -- 1. OVERWORLD HM & FIELD MOVE BYPASS
    -- ==========================================
    mod.hooks:wrap("fieldmove.eligibility", function(nextFn, moveId, ctx)
      -- Vanilla check: Pokemon that naturally know the move take priority[span_0](start_span)[span_0](end_span).
      local mon, slot = nextFn(moveId, ctx)
      if mon then return mon, slot end

      local inventory = ctx.save and ctx.save.inventory
      if inventory then
        for itemId, rawCount in pairs(inventory) do
          local idStr = tostring(itemId)
          local count = tonumber(rawCount) or (rawCount and 1) or 0
          
          if count > 0 then
            -- Matches HMs or TMs containing the move name (e.g. "HM_SURF", "TM_HEADBUTT")
            if (idStr:match("HM") or idStr:match("TM")) and idStr:match(moveId) then
              -- Return the first valid Pokemon as the surrogate[span_1](start_span)[span_1](end_span)
              for index, partyMon in ipairs(ctx.party or {}) do
                -- Eggs cannot use field moves[span_2](start_span)[span_2](end_span)
                if not partyMon.egg then return partyMon, index end
              end
            end
          end
        end
      end
      
      return nil
    end)

    -- ==========================================
    -- 2. PARTY MENU FIELD MOVE INJECTION
    -- ==========================================
    mod.hooks:wrap("ui.party.submenu", function(nextFn, game, items, mon, ctx)
      local menuItems = nextFn(game, items, mon, ctx)
      
      if ctx.battle or (mon and mon.isEgg) then
        return menuItems
      end
      
      local knownMenuIds = {}
      local insertPos = 1
      for i, item in ipairs(menuItems) do
        knownMenuIds[item.id] = true
        if item.id == "STATS" then
          insertPos = i
        end
      end
      
      local ownedMoves = {}
      local inventory = game.save and game.save.inventory
      if inventory and game.data and game.data.items then
        for itemId, rawCount in pairs(inventory) do
          local count = tonumber(rawCount) or (rawCount and 1) or 0
          if count > 0 then
            local itemDef = game.data.items[itemId]
            if itemDef and itemDef.teaches then
              ownedMoves[itemDef.teaches] = true
            end
          end
        end
      end
      
      local canLearn = {}
      local speciesDef = game.data and game.data.pokemon and game.data.pokemon[mon.species]
      if speciesDef and speciesDef.tmhm then
        for _, moveId in ipairs(speciesDef.tmhm) do
          canLearn[moveId] = true
        end
      end
      
      local FIELD_MOVES = {
        "CUT", "FLY", "SURF", "STRENGTH", "FLASH", "WATERFALL", "WHIRLPOOL", "DIG",
        "TELEPORT", "SOFTBOILED", "HEADBUTT", "ROCK_SMASH", "MILK_DRINK", "SWEET_SCENT"
      }
      
      local movesDef = game.data and game.data.moves
      for _, moveId in ipairs(FIELD_MOVES) do
        if not knownMenuIds[moveId] and ownedMoves[moveId] and canLearn[moveId] then
          local moveName = (movesDef and movesDef[moveId] and movesDef[moveId].name) or moveId
          
          table.insert(menuItems, insertPos, {
            id = moveId,
            label = moveName,
            fieldMove = true
          })
          
          insertPos = insertPos + 1
        end
      end
      
      return menuItems
    end)

    mod.log:info("Complete Overworld & Party Menu Field Move bypass injected successfully.")
  else
    mod.log:error("Field Move injection failed: mod.hooks.wrap not found.")
  end
end
