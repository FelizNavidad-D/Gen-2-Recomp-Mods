return function(mod)
  -- ==========================================
  -- 1. INFINITE TMs
  -- ==========================================
  local ItemEffects = require("src.inventory.ItemEffects")
  if ItemEffects and ItemEffects.use then
    local originalUse = ItemEffects.use
    ItemEffects.use = function(data, save, itemId, target, battle, moveIndex, ow)
      local result, payload, extra = originalUse(data, save, itemId, target, battle, moveIndex, ow)
      if result == "learn" then result = "learnkept" end
      return result, payload, extra
    end
    mod.log:info("Infinite TMs injected.")
  end

  -- ==========================================
  -- 2. UNIVERSAL HM DELETER (Gen 2 TM Bypass)
  -- ==========================================
  local moveDeleter = mod.content.screens:get("Gen2MoveDeleter")
  
  if type(moveDeleter) == "table" and type(moveDeleter.new) == "function" then
    local orig_new = moveDeleter.new
    
    moveDeleter.new = function(gameObj, opts, ...)
      if opts and opts.onChoose and opts.mon then
        local orig_onChoose = opts.onChoose
        
        opts.onChoose = function(slot)
          local old = opts.mon.moves[slot]
          local orig_id = old and old.id
          local is_hm = orig_id and (orig_id == "CUT" or orig_id == "FLY" or orig_id == "SURF" or orig_id == "STRENGTH" or orig_id == "FLASH" or orig_id == "WATERFALL" or orig_id == "WHIRLPOOL")
          
          -- Safely check the state stack to ensure this is TM learning, NOT the Blackthorn Deleter or an Ether[span_5](start_span)[span_5](end_span)
          local states = gameObj.stack.states
          local prev_state = states[#states - 1]
          local prompt_text = prev_state and (prev_state.text or prev_state.string or "")
          local is_learn_move = tostring(prompt_text):match("Which move should")
          
          local orig_say = gameObj.say
          
          -- Only apply the disguise if we are actively learning a TM
          if is_hm and is_learn_move then
            old.id = "DUMMY_HM"
            
            gameObj.say = function(this, text, onDone, sayOpts)
              if text:match("DUMMY_HM") then
                local oldDef = (gameObj.data.moves or {})[orig_id]
                local realName = (oldDef and oldDef.name) or orig_id
                text = text:gsub("DUMMY_HM", realName)
              end
              this.say = orig_say
              return orig_say(this, text, onDone, sayOpts)
            end
          end
          
          -- Run the original choice logic safely
          local ok, err = pcall(orig_onChoose, slot)
          
          -- Always restore the original ID to prevent cascading errors in other systems
          if old and old.id == "DUMMY_HM" then old.id = orig_id end
          if gameObj.say ~= orig_say then gameObj.say = orig_say end
          
          if not ok then error(err) end
        end
      end
      return orig_new(gameObj, opts, ...)
    end
    
    mod.content.screens:override("Gen2MoveDeleter", moveDeleter)
    mod.log:info("Universal HM Deleter injected.")
  end
end
