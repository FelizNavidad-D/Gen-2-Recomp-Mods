return function(mod)
  local World = require("src.world.gen2.World")

  -- 1. Uncap the Daily Limit (Flag 80 is ENGINE_DAILY_BUG_CONTEST)
  local vanilla_engineFlag = World.engineFlag
  World.engineFlag = function(self, flag)
    if flag == 80 then return false end
    return vanilla_engineFlag(self, flag)
  end

  local vanilla_setEngineFlag = World.setEngineFlag
  World.setEngineFlag = function(self, flag, value)
    if flag == 80 then return end -- Drop the write so it never saves
    return vanilla_setEngineFlag(self, flag, value)
  end

  -- Helper to check if we are in the National Park Gates
  local function isContestMap(self)
    return self.map and (
      self.map.id == "ROUTE_35_NATIONAL_PARK_GATE" or 
      self.map.id == "ROUTE_36_NATIONAL_PARK_GATE"
    )
  end

  -- 2. Force the Day of the Week in the Gates
  local vanilla_weekday = World.weekday
  World.weekday = function(self)
    if isContestMap(self) then 
      return 2 -- 2 = Tuesday
    end
    return vanilla_weekday(self)
  end

  -- 3. Force the Time of Day in the Gates
  local vanilla_timeOfDayId = World.timeOfDayId
  World.timeOfDayId = function(self)
    if isContestMap(self) then 
      return 1 -- 1 = Day (0=Morn, 1=Day, 2=Nite, 3=Dark)
    end
    return vanilla_timeOfDayId(self)
  end
end
